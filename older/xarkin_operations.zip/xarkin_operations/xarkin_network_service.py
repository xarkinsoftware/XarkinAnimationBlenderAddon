# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_INITIATE_SESSION = 'initiate_session'
XAR_FETCH_USER_INFO = 'mogen_get_user_info'
XAR_EXCLUDED_SEGMENT = 'excluded_segment'
XAR_INVISIBLE_MARKER = '_fill_in_invisible'
XAR_INTERVAL_OPERATION = 'interval_operation'
XAR_CHANGE_PASSWORD = 'change_password'
XAR_INVALID_USERID_OR_PASSWORD = 'Invalid Userid or Password'
XAR_REFLECT_PAGE = 'Generated.html'
XAR_REFLECT_REQUEST = 'reflect_request'
XAR_REFLECT_MAPPING_REQUEST = 'mapping_reflect_request'
XAR_REFLECT_STUDIO_REQUEST = 'studio_reflect_request'

XAR_MIN_PASSWORD_LENGTH = 8

XAR_STATE_IDLE = 0
XAR_STATE_REQUEST_IN_PROGRESS = 1
XAR_STATE_RESULT_AVAILABLE = 2
XAR_STATE_IMPORTING_FRAMES = 3

import bpy
import importlib
import xml.dom.minidom
import urllib
import threading
import time
import datetime
from .websocket import WebSocketApp
import webbrowser

from . import xarkin_utilities
from . import xarkin_session_data
from . import xarkin_xml_exporter
from . import xarkin_frame_importer
from . import xarkin_message_dialog

global_pk_exponent = ''
global_pk_modulus = ''

global_userid = '_no_userid_'
global_password = ''
global_new_password = ''
global_request_parameters_xml = ''
global_mapping_xml = ''
global_interval_xml = ''
global_first_import_frame = -1

global_request_state = XAR_STATE_IDLE
global_request_index = 0
global_import_frame = -1

browser_counter = 0

global_arm_name = ''
global_sequence_xml = ''
global_insertion_frame = 0
global_progress_value = -1

global_user_info_refresh_time = ''

# STATE MANAGEMENT
def show_network_response_message(message_heading, message):
    if (message_heading == None) or (message_heading == ''):
        bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg=message)
    else:
        bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg=message_heading + ':\n' + message)

def idle():
    global global_request_state
    return global_request_state == XAR_STATE_IDLE

def request_in_progress():
    global global_request_state
    return global_request_state == XAR_STATE_REQUEST_IN_PROGRESS

def result_available():
    global global_request_state
    return global_request_state == XAR_STATE_RESULT_AVAILABLE

def importing_frames():
    global global_request_state
    return global_request_state == XAR_STATE_IMPORTING_FRAMES

def abort():
    global global_request_state
    global global_request_index
    global global_import_frame
    global_request_state = XAR_STATE_IDLE
    global_request_index = global_request_index + 1
    global_import_frame = -1
    xarkin_session_data.server_result = None
    xarkin_session_data.frame_node_count = -1

# COMMON SOCKET METHODS
def on_error(ws, error):
    abort()
    bpy.app.timers.register(lambda: show_network_response_message(None, 'Xarkin server could not be reached.'), first_interval=0)
    print("WebSocket Error:" + str(error))

def on_close(ws, number, message):
    print("WebSocket Connection Closed with number " + str(number) + " and message " + str(message))

def extract_public_key(message):
    global global_pk_exponent
    global global_pk_modulus
    modulus_pos = str(message).find('pk_modulus')
    exponent_pos = str(message).find('pk_exponent')
    if (modulus_pos > 0) and (exponent_pos > 0):
        exponent_start_pos = message.find('"', exponent_pos) + 1
        exponent_end_pos = message.find('"', exponent_start_pos + 1)
        modulus_start_pos = message.find('"', modulus_pos) + 1
        modulus_end_pos = message.find('"', modulus_start_pos + 1)
        global_pk_exponent = int(message[exponent_start_pos:exponent_end_pos])
        global_pk_modulus = int(message[modulus_start_pos:modulus_end_pos])

# INITIATE SESSION
def initiate_session():
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    if (server_address.find('localhost') >= 0):
        print("Attempting connection to localhost.")
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_initiate_session_response,
                            on_error=process_initiate_session_error,
                            on_close=on_close)
    ws.on_open = send_initiate_session_request
    ws.run_forever()

def send_initiate_session_request(ws):
    global global_userid
    message = 'requested_element=' + XAR_INITIATE_SESSION\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER
    ws.send(message)

def process_initiate_session_error(ws, message):
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))
    bpy.app.timers.register(lambda: show_network_response_message(None, 'Xarkin session initiation failed.'), first_interval=0)

def process_initiate_session_response(ws, message):
    extract_public_key(message)
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))
    xarkin_session_data.fetch_user_data()

# SET USERID AND PASSWORD
def encrypt_password(password):
    global global_pk_exponent
    global global_pk_modulus
    password_int = int.from_bytes(password.encode("ascii"), "little")
    encrypted_password_int = pow(password_int, global_pk_exponent, global_pk_modulus)
    encrypted_password = str(encrypted_password_int)
    return encrypted_password

def set_user_id_and_password(userid, new_password):
    global global_userid
    global global_new_password
    global_userid = userid
    global_new_password = new_password
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_password_update_response,
                            on_error=process_password_update_response,
                            on_close=on_close)
    ws.on_open = send_password_update_request
    ws.run_forever()

def send_password_update_request(ws):
    global global_userid
    global global_password
    global global_new_password
    global global_pk_exponent
    global global_pk_modulus

    request_password = global_password
    if (request_password == ''):
        request_password = global_new_password

    encrypted_password = encrypt_password(request_password)

    encrypted_new_password = encrypt_password(global_new_password)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&encrypted_new_password=' + encrypted_new_password\
        + '&requested_element=' + XAR_CHANGE_PASSWORD
    ws.send(message)

def process_password_update_response(ws, message):
    global global_password
    if (message.startswith("<fail")):
        global_password = ''
        clear_password()
        print("Password save failed.")
        bpy.app.timers.register(lambda: show_network_response_message(None, 'Password change failed.'), first_interval=0)
    else:
        global global_userid
        global global_new_password
        global_password = global_new_password
        xarkin_session_data.save_userid_and_password_locally(global_userid, global_password)
        print("Password saved.")
        bpy.app.timers.register(lambda: show_network_response_message(None, 'Password saved.'), first_interval=0)
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

def clear_password():
    try:
        userid_filepath = xarkin_session_data.get_userid_filepath()
        with open(userid_filepath, 'r') as userid_file:
            userid_password = userid_file.read()
            line_split = userid_password.split(':')
            userid = line_split[0]
        with open(userid_filepath, 'w') as userid_file:
            userid_file.write(userid + ':')
    except Exception as exc:
        print("Failed to access userid file.")

# FETCH USER INFO
def fetch_user_info(userid, password):
    global global_userid
    global global_password
    global_userid = userid
    global_password = password
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_user_info_response,
                            on_error=process_user_info_response,
                            on_close=on_close)
    ws.on_open = send_user_info_request
    ws.run_forever()

def send_user_info_request(ws):
    global global_userid
    global global_password
    global global_pk_exponent
    global global_pk_modulus

    encrypted_password = encrypt_password(global_password)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_FETCH_USER_INFO
    ws.send(message)

def process_user_info_response(ws, message):
    global global_userid
    global global_password
    if (message.find(XAR_INVALID_USERID_OR_PASSWORD) >= 0):
        global_password = ''
        xarkin_session_data.save_userid_and_password_locally(global_userid, '')
        try:
            ws.close()
        except Exception as exc:
            print("WebSocket close exception\n" + str(exc))
        if (len(global_userid) == 0):
            bpy.app.timers.register(lambda: show_network_response_message(None, 'Not logged in.'), first_interval=0)
        else:
            bpy.app.timers.register(lambda: show_network_response_message(None, 'Login for ' + global_userid + ' failed.'), first_interval=0)
        return
    global global_user_info_refresh_time
    global_user_info_refresh_time = str(datetime.datetime.now())
    mappings_table = xarkin_session_data.get_mappings_table()
    mappings_bone_list_table = xarkin_session_data.get_mappings_bone_list_table()
    mappings_table.clear()
    mappings_bone_list_table.clear()
    cycles_table = xarkin_session_data.get_cycles_table()
    cycles_table.clear()
    message_type_string = str(type(message))
    if (message_type_string.find('ConnectionRefusedError') < 0):
        try:
            dom = xml.dom.minidom.parseString(message)
            mappings_nodes = dom.getElementsByTagName('mappings')
            if (len(mappings_nodes) > 0):
                mappings_node = mappings_nodes[0]
                mappings = mappings_node.getElementsByTagName('mapping')
                for mapping in mappings:
                    if (mapping.hasAttribute('display_name')):
                        mapping_name = mapping.getAttribute('display_name')
                    else:
                        mapping_name = mapping.getAttribute('name')
                        print("Mapping " + mapping_name + " has no display name.")
                    excluded_bone_list = []
                    excluded_nodes = mapping.getElementsByTagName(XAR_EXCLUDED_SEGMENT)
                    for seg in excluded_nodes:
                        excluded_bone_list.append(seg.getAttribute('name'))
                    mapping_bone_list = []
                    foreign_assembly_node = mapping.getElementsByTagName('foreign_assembly')[0]
                    bones = foreign_assembly_node.getElementsByTagName('segment')
                    for bone in bones:
                        bone_name = bone.getAttribute('name')
                        if (not (bone_name in mapping_bone_list)) and (not bone_name.endswith(XAR_INVISIBLE_MARKER)):
                            mapping_bone_list.append(bone_name)
                    mapping_bone_list.sort()
                    mappings_table[mapping_name] = mapping.toxml()
                    mappings_bone_list_table[mapping_name] = mapping_bone_list
            cycles_nodes = dom.getElementsByTagName('cycles')
            if (len(cycles_nodes) > 0):
                cycles_node = cycles_nodes[0]
                cycles = cycles_node.getElementsByTagName('mogen')
                for cycle in cycles:
                    if (cycle.hasAttribute('display_name')):
                        cycle_name = cycle.getAttribute('display_name')
                    else:
                        cycle_name = cycle.getAttribute('name')
                        print("Cycle " + cycle_name + " has no display name.")
                    cycles_table[cycle_name] = cycle.toxml()
        except Exception as exc:
            print("Mappings message processing error\n" + str(exc))
        bpy.app.timers.register(lambda: show_network_response_message(None,' Logged in as ' + global_userid), first_interval=0)
    else:
        print("No response to server request for mappings.")
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

# INTERVAL OPERATION
def interval_service_request(request_parameters_xml, mapping_xml, interval_xml):
    global global_request_parameters_xml
    global global_mapping_xml
    global global_interval_xml
    global_request_parameters_xml = request_parameters_xml
    global_mapping_xml = mapping_xml
    global_interval_xml = interval_xml
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_interval_operation_response,
                            on_error=on_error,
                            on_close=on_close)
    ws.on_open = send_interval_operation_request
    ws.run_forever()

def send_interval_operation_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_request_parameters_xml
    global global_mapping_xml
    global global_interval_xml
    global global_pk_exponent
    global global_pk_modulus

    encrypted_password = encrypt_password(global_password)

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encoded_parameters = urllib.parse.quote(global_request_parameters_xml)
    encoded_mapping = urllib.parse.quote(global_mapping_xml)
    encoded_interval = urllib.parse.quote(global_interval_xml)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_INTERVAL_OPERATION\
        + '&request_index=' + str(global_request_index)\
        + '&request_parameters=' + encoded_parameters\
        + '&mapping=' + encoded_mapping\
        + '&interval=' + encoded_interval
    ws.send(message)

def process_interval_operation_response(ws, message):
    extract_public_key(message)
    global global_request_state
    global global_request_index
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Interval Operation', response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                xarkin_session_data.set_server_result(message)
#                xarkin_session_data.server_result = message
                global_request_state = XAR_STATE_RESULT_AVAILABLE
                bpy.app.timers.register(lambda: show_network_response_message(None, 'Operation Results Available'), first_interval=0)
            else:
                print("Response ignored because index " + str(request_index) + " doesn't match expected " + str(global_request_index))
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

# CYCLE CAPTURE
def cycle_capture_request(request_parameters_xml, mapping_xml, interval_xml):
    global global_request_parameters_xml
    global global_mapping_xml
    global global_interval_xml
    global_request_parameters_xml = request_parameters_xml
    global_mapping_xml = mapping_xml
    global_interval_xml = interval_xml
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_cycle_capture_response,
                            on_error=on_error,
                            on_close=on_close)
    ws.on_open = send_cycle_capture_request
    ws.run_forever()

def send_cycle_capture_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_request_parameters_xml
    global global_mapping_xml
    global global_interval_xml
    global global_pk_exponent
    global global_pk_modulus

    encrypted_password = encrypt_password(global_password)

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encoded_parameters = urllib.parse.quote(global_request_parameters_xml)
    encoded_mapping = urllib.parse.quote(global_mapping_xml)
    encoded_interval = urllib.parse.quote(global_interval_xml)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_INTERVAL_OPERATION\
        + '&request_index=' + str(global_request_index)\
        + '&request_parameters=' + encoded_parameters\
        + '&mapping=' + encoded_mapping\
        + '&interval=' + encoded_interval
    ws.send(message)

def process_cycle_capture_response(ws, message):
    extract_public_key(message)
    global global_request_parameters_xml
    global global_request_state
    global global_request_index
    global global_user_info_refresh_time
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Cycle Capture', response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                message_dom = xml.dom.minidom.parseString(message)
                mogen_node = message_dom.getElementsByTagName('mogen')[0]
                if mogen_node.hasAttribute('display_name'):
                    cycle_name = mogen_node.getAttribute('display_name')
                else:
                    cycle_name = mogen_node.getAttribute('name')
                    print("Cycle " + cycle_name + " has no display name.")
                cycles_table = xarkin_session_data.get_cycles_table()
                print("Saving cycle " + cycle_name)
                cycles_table[cycle_name] = message
                global_user_info_refresh_time = str(datetime.datetime.now())
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Cycle Capture', 'Cycle successfully saved.'), first_interval=0)
            else:
                print("Response ignored because index " + str(request_index) + " doesn't match expected " + str(global_request_index))
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

# POSE IMPORT
def get_import_armature_name():
    global global_request_parameters_xml
    if (global_request_parameters_xml == None):
        return None
    try:
        arm_name = None
        request_dom = xml.dom.minidom.parseString(global_request_parameters_xml)
        parameter_nodes = request_dom.getElementsByTagName("parameter")
        for parameter_node in parameter_nodes:
            parameter_name = parameter_node.getAttribute('name')
            if (parameter_name == 'armature_name'):
                arm_name = parameter_node.getAttribute('value')
        return arm_name
    except:
        return None

def get_number_of_import_frames():
    if (xarkin_session_data.frame_node_count == -1):
        return None
    return xarkin_session_data.frame_node_count

def initiate_import():
    global global_request_state
    global global_import_frame
    global global_request_parameters_xml
    global global_arm_name
    global global_sequence_xml
    global global_insertion_frame
    global global_progress_value
    global global_first_import_frame

    global_import_frame = 0
    global_request_state = XAR_STATE_IMPORTING_FRAMES
    
    try:
        request_dom = xml.dom.minidom.parseString(global_request_parameters_xml)
    except:
        xarkin_editor_import_alert("Invalid sequence.")
        return False

    parameter_nodes = request_dom.getElementsByTagName("parameter")
    for parameter_node in parameter_nodes:
        parameter_name = parameter_node.getAttribute('name')
        if (parameter_name == 'armature_name'):
            arm_name = parameter_node.getAttribute('value')
        if (parameter_name == 'first_frame'):
            first_frame = int(parameter_node.getAttribute('value'))

    global_arm_name = arm_name
    global_sequence_xml = xarkin_session_data.server_result
    global_insertion_frame = first_frame
    xarkin_frame_importer.current_import_frame = -1
    global_progress_value = -1
    global_first_import_frame = -1
    bpy.app.timers.register(launch_frame_importer, first_interval=0)

def launch_frame_importer():
    global global_arm_name
    global global_sequence_xml
    global global_insertion_frame
    arm_name = global_arm_name
    sequence_xml = global_sequence_xml
    first_frame = global_insertion_frame
    xarkin_frame_importer.initiate_frames_import(arm_name, sequence_xml, first_frame)
    abort()

#reflect html
def reflect_mapping(sequence_xml):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)
    ws.xml = sequence_xml
    ws.on_open = send_mapping_reflect_request
    ws.run_forever()

def send_mapping_reflect_request(ws):
    global global_userid
    global global_password
    encrypted_password = encrypt_password(global_password)
    encoded_xml = urllib.parse.quote(ws.xml)
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_MAPPING_REQUEST\
        + '&xml=' + encoded_xml
    ws.send(message)

def reflect_studio(interval_xml, is_cycle_str, is_walk_str, mapping_xml):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)
    ws.interval_xml = interval_xml
    ws.is_cycle_str = is_cycle_str
    ws.is_walk_str = is_walk_str
    ws.mapping_xml = mapping_xml
    ws.on_open = send_studio_reflect_request
    ws.run_forever()

def send_studio_reflect_request(ws):
    global global_userid
    global global_password
    encrypted_password = encrypt_password(global_password)
    encoded_interval = urllib.parse.quote(ws.interval_xml)
    encoded_mapping = urllib.parse.quote(ws.mapping_xml)
    is_cycle = ws.is_cycle_str
    is_walk = ws.is_walk_str
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_STUDIO_REQUEST\
        + '&interval=' + encoded_interval\
        + '&sequence_is_cycle=' + is_cycle\
        + '&sequence_is_walk=' + is_walk\
        + '&mapping=' + encoded_mapping
    ws.send(message)

def reflect_single(html):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)
    ws.html = html
    ws.on_open = send_reflect_request
    ws.run_forever()

def send_reflect_request(ws):
    global global_userid
    global global_password
    encrypted_password = encrypt_password(global_password)
    encoded_html = urllib.parse.quote(ws.html)
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_REQUEST\
        + '&html=' + encoded_html
    ws.send(message)

def process_reflect_response(ws, message):
    if (message.startswith('<fail')):
        print("Launch failed.")
        bpy.app.timers.register(lambda: show_network_response_message(None, 'Mapping launch failed.'), first_interval=0)
    else:
        server_address = xarkin_session_data.fetch_config_parameter('remote_server')
        web_page_address = str("https://" + server_address + "/" + XAR_REFLECT_PAGE + '?id=' + message)
        webbrowser.open(web_page_address, new=1)
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

def on_reflect_error(ws, error):
    bpy.app.timers.register(lambda: show_network_response_message(None, 'Xarkin server could not be reached.'), first_interval=0)
    print("WebSocket Reflect Error:" + str(error))

def reflect_multiple(htmls):
    reflected_page_addresses = []
    for i in range(len(htmls)):
        reflected_page_addresses.append('')
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    for i in range(len(htmls)):
        ws = WebSocketApp(web_socket_address,
                                on_message=process_reflect_multiple_response,
                                on_error=on_reflect_error,
                                on_close=on_close)
        ws.html = htmls[i]
        ws.html_index = i
        ws.reflected_page_addresses = reflected_page_addresses
        ws.on_open = send_reflect_request
        ws.run_forever()

def process_reflect_multiple_response(ws, message):
    global browser_counter
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_page_address = "https://" + server_address + "/" + XAR_REFLECT_PAGE + '?id=' + message
    ws.reflected_page_addresses[ws.html_index] = web_page_address
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))
    all_received = True
    for address in ws.reflected_page_addresses:
        all_received = all_received and (len(address) > 0)
    if all_received:
        # browser_counter += 1
        # print("browser_counter set to " + str(browser_counter))
        # first = True
        # for address in ws.reflected_page_addresses:
        #     if (first):
        #         webbrowser.open(address, new=browser_counter)
        #     else:
        #         webbrowser.open(address, new=browser_counter)
        #     first = False
        webbrowser.open_new(' '.join(ws.reflected_page_addresses))


# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_NO_MAPPINGS_AVAILABLE = "No Mappings Available"
#XAR_MAX_PRE_INSERTION_TIME = 1

import bpy
import importlib
import time
import threading
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty
        )
from . import xarkin_session_data
from . import xarkin_utilities
from . import xarkin_message_dialog
from . import xarkin_network_service
from . import xarkin_xml_exporter

global_parameters_xml = ''
global_mapping_xml = ''
global_interval_xml = ''

def get_armature_items(self, context):
    item_list = []
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

def get_mapping_items(self, context):
    item_list = []
    mappings_table = xarkin_session_data.get_mappings_table()
    mappings_bone_list_table = xarkin_session_data.get_mappings_bone_list_table()
    if (mappings_table == None):
        item_list.append(tuple([XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE]))
    else:
        current_armature_name = self.armatures_prop
        armature_bone_list = xarkin_utilities.get_armature_bone_list(current_armature_name)
        for mapping_name in mappings_table.keys():
            mapping_bone_list = mappings_bone_list_table[mapping_name]
            if (xarkin_utilities.same_string_array(mapping_bone_list, armature_bone_list)):
                item_list.append(tuple([mapping_name, mapping_name, mapping_name]))
        if (len(item_list) == 0):
            item_list.append(tuple([XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE]))
    return item_list

def make_service_call():
    global global_parameters_xml
    global global_mapping_xml
    global global_interval_xml
    xarkin_network_service.interval_service_request(global_parameters_xml, global_mapping_xml, global_interval_xml)

class XarkinRunStepDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_run_step_dialog"
    bl_label = "Modify Run Step"
    bl_description = "Requests a modification of the distance, height, and elevation change for a running step"

    network_service_busy = False

    wait_and_abort_options = [("wait", "Keep Waiting...", "Keep waiting for the current operation to complete."), ("abort", "Abort", "Abandon the current operation.")]
    wait_or_abort_prop: EnumProperty(name='Actions', items=wait_and_abort_options, default=wait_and_abort_options[0][0])

    armatures_prop: EnumProperty(items=get_armature_items, name="Armature", default=None)
    mappings_prop: EnumProperty(items=get_mapping_items, name="Mapping", default=None)
    first_frame_prop: IntProperty(name="First Frame", default=1, min=1)
    last_frame_prop: IntProperty(name="Last Affected", default=1, min=1)
    step_distance_prop: FloatProperty(name="Step Distance Change", default=0, precision=3)
    leap_height_prop: FloatProperty(name="Leap Height", default=0, precision=3)
    elevation_change_prop: FloatProperty(name="Elevation Change", default=0, precision=3)
    
    def draw(self, context):
        layout = self.layout
        
        if self.network_service_busy:
            layout.label(text="An operation is already in progress!")
            for option in self.wait_and_abort_options:
                row = layout.row()
                row.prop_enum(self, 'wait_or_abort_prop', option[0], text=option[1])
        else:
            col = layout.column()
            row = col.row()
            row.prop(self, 'armatures_prop')
            row = col.row()
            row.prop(self, 'mappings_prop')
            row = col.row()
            row.prop(self, 'first_frame_prop')
            row = col.row()
            row.prop(self, 'last_frame_prop')
            row = col.row()
            row.prop(self, 'step_distance_prop')
            row = col.row()
            row.prop(self, 'leap_height_prop')
            row = col.row()
            row.prop(self, 'elevation_change_prop')

    def invoke(self, context, event):
        self.network_service_busy = not xarkin_network_service.idle()

        armature_count = 0
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                armature_count = armature_count + 1
        if (armature_count == 0):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No Armatures Available')
            return  {'FINISHED'}

        subject_arm_name = xarkin_session_data.get_subject_armature_name()
        self.armatures_prop = subject_arm_name
        if (subject_arm_name != None):
            armature_obj = bpy.data.objects[self.armatures_prop]
            anim_data = armature_obj.animation_data
            if (anim_data is not None) and (anim_data.action is not None):
                last_frame = 1
                for fcurve in anim_data.action.fcurves:
                    for key_frame in fcurve.keyframe_points:
                        if key_frame.co.x > last_frame:
                            last_frame = key_frame.co.x
                self.last_frame_prop = int(last_frame)

        self.first_frame_prop = min(int(self.last_frame_prop), bpy.context.scene.frame_current)

        most_recent_mapping_name = xarkin_session_data.get_session_variable("most_recent_mapping_name")
        if (not most_recent_mapping_name == None):
            m_items = get_mapping_items(self, None)
            for item in m_items:
                if (item[1] == most_recent_mapping_name):
                    self.mappings_prop = most_recent_mapping_name

        most_recent_step_distance = xarkin_session_data.get_session_variable("most_recent_step_distance")
        if (not most_recent_step_distance == None):
                self.step_distance_prop = most_recent_step_distance
                
        most_recent_leap_height = xarkin_session_data.get_session_variable("most_recent_leap_height")
        if (not most_recent_leap_height == None):
                self.leap_height_prop = most_recent_leap_height
                
        most_recent_elevation_change = xarkin_session_data.get_session_variable("most_recent_elevation_change")
        if (not most_recent_elevation_change == None):
            self.elevation_change_prop = most_recent_elevation_change
                
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if self.network_service_busy:
            if (self.wait_or_abort_prop == 'abort'):
                xarkin_network_service.abort()
            return {'FINISHED'}
        xarkin_session_data.set_session_variable("most_recent_armature", self.armatures_prop)
        xarkin_session_data.set_session_variable("most_recent_mapping_name", self.mappings_prop)
        xarkin_session_data.set_session_variable("most_recent_step_distance", self.step_distance_prop)
        xarkin_session_data.set_session_variable("most_recent_leap_height", self.leap_height_prop)
        xarkin_session_data.set_session_variable("most_recent_elevation_change", self.elevation_change_prop)
        if (self.mappings_prop == XAR_NO_MAPPINGS_AVAILABLE):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No mappings for this character.\nPlease create one before attempting operations.')
            return {'FINISHED'}
        first_frame = self.first_frame_prop
        last_frame = self.last_frame_prop
        if (last_frame == first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='First Frame and Last Frame should surround the\n'\
                'interval containing the step you would like to modify.\n'\
                    'The first candidate step in that interval will be modified.')
            return {'FINISHED'}
        elif (last_frame < first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Last Frame must be greater than First Frame.')
            return {'FINISHED'}
        elif ((last_frame - first_frame) < 10):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='This looks like too few frames to contain a step.\n'\
                'This warning is issued if the interval is less than 10 frames.')
            return {'FINISHED'}

        bpy.ops.ed.undo_push(message="Before requesting run step modification.")
        
        mapping_xml = xarkin_session_data.get_mappings_table()[self.mappings_prop]

        exporter = xarkin_xml_exporter.EditorXMLExporter()

        first_export_frame = first_frame
        lead_buffer = 0
        max_pre_insertion_frames = 2 # bpy.context.scene.render.fps * XAR_MAX_PRE_INSERTION_TIME
        for i in range(max_pre_insertion_frames):
            if (first_export_frame > 0):
                first_export_frame = first_export_frame - 1
                lead_buffer = lead_buffer + 1
        trail_buffer = 0
        interval_xml = exporter.get_mogen(self.armatures_prop, first_export_frame, last_frame)

        parameters_xml = '<parameters>'
        parameters_xml += '<parameter name="operation" value="modify_run_step" />'
        parameters_xml += '<parameter name="armature_name" value="' + self.armatures_prop + '" />'
        parameters_xml += '<parameter name="mapping_name" value="' + self.mappings_prop + '" />'
        parameters_xml += '<parameter name="first_frame" value="' + str(first_frame) + '" />'
        parameters_xml += '<parameter name="last_frame" value="' + str(last_frame) + '" />'
        parameters_xml += '<parameter name="lead_buffer" value="' + str(lead_buffer) + '" />'
        parameters_xml += '<parameter name="trail_buffer" value="' + str(trail_buffer) + '" />'
        parameters_xml += '<parameter name="step_distance" value="' "{:10.3f}".format(self.step_distance_prop)  + '" />'
        parameters_xml += '<parameter name="sequence_height" value="' "{:10.3f}".format(self.leap_height_prop)  + '" />'
        parameters_xml += '<parameter name="sequence_elevation_change" value="' "{:10.3f}".format(self.elevation_change_prop)  + '" />'
        parameters_xml += '</parameters>'

        global global_parameters_xml
        global global_mapping_xml
        global global_interval_xml
        global_parameters_xml = parameters_xml
        global_mapping_xml = mapping_xml
        global_interval_xml = interval_xml
        xarkin_network_service.global_first_import_frame = first_frame
        thread = threading.Thread(target=make_service_call)
        thread.start()
        return {'FINISHED'}

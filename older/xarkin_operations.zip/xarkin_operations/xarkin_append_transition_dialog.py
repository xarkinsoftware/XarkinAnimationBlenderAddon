# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_NO_MAPPINGS_AVAILABLE = "No Mappings Available"

import bpy
import importlib
import xml.dom.minidom
import time
import threading
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty
        )
from . import xarkin_session_data
from . import xarkin_utilities
from . import xarkin_message_dialog
from . import xarkin_network_service
from . import xarkin_xml_exporter

global_parameters_xml = ''
global_mapping_xml = ''
global_interval_xml = ''

global_cached_cycles_list = None
global_user_info_refresh_time = ''

def get_armature_items(self, context):
    item_list = []
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

def get_mapping_items(self, context):
    item_list = []
    mappings_table = xarkin_session_data.get_mappings_table()
    mappings_bone_list_table = xarkin_session_data.get_mappings_bone_list_table()
    if (mappings_table == None):
        item_list.append(tuple([XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE]))
    else:
        current_armature_name = self.armatures_prop
        armature_bone_list = xarkin_utilities.get_armature_bone_list(current_armature_name)
        for mapping_name in mappings_table.keys():
            mapping_bone_list = mappings_bone_list_table[mapping_name]
            if (xarkin_utilities.same_string_array(mapping_bone_list, armature_bone_list)):
                item_list.append(tuple([mapping_name, mapping_name, mapping_name]))
        if (len(item_list) == 0):
            item_list.append(tuple([XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE]))
    return item_list

def make_service_call():
    global global_parameters_xml
    global global_mapping_xml
    global global_interval_xml
    xarkin_network_service.interval_service_request(global_parameters_xml, global_mapping_xml, global_interval_xml)

def get_cycle_items(self, context):
    global global_cached_cycles_list
    global global_user_info_refresh_time
    if (global_cached_cycles_list != None) and (global_user_info_refresh_time == xarkin_network_service.global_user_info_refresh_time):
        return global_cached_cycles_list
    item_list = []
    mappings_table = xarkin_session_data.get_mappings_table()
    cycles_table = xarkin_session_data.get_cycles_table()
    if (cycles_table == None) or (mappings_table == None):
        item_list.append(tuple([XAR_NO_CYCLES_AVAILABLE, XAR_NO_CYCLES_AVAILABLE, XAR_NO_CYCLES_AVAILABLE]))
    else:
        try:
            current_mapping_name = self.mappings_prop
            current_mapping_xml = mappings_table[current_mapping_name]
            mapping_topology_index = current_mapping_xml.find('topology')
            mapping_snippet = current_mapping_xml[mapping_topology_index:mapping_topology_index + 100]
            mapping_snippet_parts = mapping_snippet.split('"')
            mapping_topology_name = mapping_snippet_parts[1]
            for cycle_name in cycles_table.keys():
                cycle_xml = cycles_table[cycle_name]
                cycle_topology_index = cycle_xml.find('topology')
                cycle_snippet = cycle_xml[cycle_topology_index:cycle_topology_index + 100]
                cycle_snippet_parts = cycle_snippet.split('"')
                cycle_topology_name = cycle_snippet_parts[1]
                if (cycle_topology_name == mapping_topology_name):
                    item_list.append(tuple([cycle_name, cycle_name, cycle_name]))
            if (len(item_list) == 0):
                item_list.append(tuple([XAR_NO_CYCLES_AVAILABLE, XAR_NO_CYCLES_AVAILABLE, XAR_NO_CYCLES_AVAILABLE]))
        except Exception as exc:
            print("Exception creating cycle items list\n" + str(exc))
    global_cached_cycles_list = item_list
    global_user_info_refresh_time = xarkin_network_service.global_user_info_refresh_time
    return item_list

class XarkinAppendTransitionDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_append_transition_dialog"
    bl_label = "Append Cycle Transition"
    bl_description = "Append a transition and one instance of a cycle or pose starting at a given frame"

    network_service_busy = False

    wait_and_abort_options = [("wait", "Keep Waiting...", "Keep waiting for the current operation to complete."), ("abort", "Abort", "Abandon the current operation.")]
    wait_or_abort_prop: EnumProperty(name='Actions', items=wait_and_abort_options, default=wait_and_abort_options[0][0])

    armatures_prop: EnumProperty(items=get_armature_items, name="Armature", default=None)
    mappings_prop: EnumProperty(items=get_mapping_items, name="Mapping", default=None)
    from_cycle_name_prop: EnumProperty(items=get_cycle_items, name="From Cycle Name", default=None)
    to_cycle_name_prop: EnumProperty(items=get_cycle_items, name="To Cycle Name", default=None)
    first_frame_prop: IntProperty(name="First Frame", default=1, min=1)
    
    def draw(self, context):
        layout = self.layout
        
        if self.network_service_busy:
            layout.label(text="An operation is already in progress!")
            for option in self.wait_and_abort_options:
                row = layout.row()
                row.prop_enum(self, 'wait_or_abort_prop', option[0], text=option[1])
        else:
            col = layout.column()
            row = col.row()
            row.prop(self, 'armatures_prop')
            row = col.row()
            row.prop(self, 'mappings_prop')
            row = col.row()
            row.prop(self, 'from_cycle_name_prop')
            row = col.row()
            row.prop(self, 'to_cycle_name_prop')
            row = col.row()
            row.prop(self, 'first_frame_prop')

    def invoke(self, context, event):
        self.network_service_busy = not xarkin_network_service.idle()

        armature_count = 0
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                armature_count = armature_count + 1
        if (armature_count == 0):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No Armatures Available')
            return  {'FINISHED'}

        subject_arm_name = xarkin_session_data.get_subject_armature_name()
        self.armatures_prop = subject_arm_name
        if (subject_arm_name != None):
            armature_obj = bpy.data.objects[self.armatures_prop]
            anim_data = armature_obj.animation_data
            if (anim_data is not None) and (anim_data.action is not None):
                last_frame = 1
                for fcurve in anim_data.action.fcurves:
                    for key_frame in fcurve.keyframe_points:
                        if key_frame.co.x > last_frame:
                            last_frame = key_frame.co.x
                self.first_frame_prop = int(last_frame) + 1

        most_recent_mapping_name = xarkin_session_data.get_session_variable("most_recent_mapping_name")
        if (not most_recent_mapping_name == None):
            m_items = get_mapping_items(self, None)
            for item in m_items:
                if (item[1] == most_recent_mapping_name):
                    self.mappings_prop = most_recent_mapping_name

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if self.network_service_busy:
            if (self.wait_or_abort_prop == 'abort'):
                xarkin_network_service.abort()
            return {'FINISHED'}
        xarkin_session_data.set_session_variable("most_recent_armature", self.armatures_prop)
        xarkin_session_data.set_session_variable("most_recent_mapping_name", self.mappings_prop)
        if (self.mappings_prop == XAR_NO_MAPPINGS_AVAILABLE):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No mappings for this character.\nPlease create one before attempting operations.')
            return {'FINISHED'}
        first_frame = self.first_frame_prop

        bpy.ops.ed.undo_push(message="Before requesting transition append.")
        
        mapping_xml = xarkin_session_data.get_mappings_table()[self.mappings_prop]

        exporter = xarkin_xml_exporter.EditorXMLExporter()

        first_export_frame = first_frame - 1
        lead_buffer = 0
        for i in range(2):
            if (first_export_frame > 0):
                first_export_frame = first_export_frame - 1
                lead_buffer = lead_buffer + 1
        last_export_frame = first_frame - 1
        interval_xml = exporter.get_mogen(self.armatures_prop, first_export_frame, last_export_frame)

        parameters_xml = '<parameters>'
        parameters_xml += '<parameter name="operation" value="append_transition" />'
        parameters_xml += '<parameter name="armature_name" value="' + self.armatures_prop + '" />'
        parameters_xml += '<parameter name="mapping_name" value="' + self.mappings_prop + '" />'
        parameters_xml += '<parameter name="first_frame" value="' + str(first_frame) + '" />'
        parameters_xml += '<parameter name="from_cycle_name" value="' + self.from_cycle_name_prop + '" />'
        parameters_xml += '<parameter name="to_cycle_name" value="' + self.to_cycle_name_prop + '" />'
        parameters_xml += '<parameter name="lead_buffer" value="' + str(lead_buffer) + '" />'
        parameters_xml += '</parameters>'

        global global_parameters_xml
        global global_mapping_xml
        global global_interval_xml
        global_parameters_xml = parameters_xml
        global_mapping_xml = mapping_xml
        global_interval_xml = interval_xml
        xarkin_network_service.global_first_import_frame = first_frame
        thread = threading.Thread(target=make_service_call)
        thread.start()
        return {'FINISHED'}

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_NO_MAPPINGS_AVAILABLE = "No Mappings Available"

import bpy
import importlib
import time
import threading
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty
        )
from . import xarkin_session_data
from . import xarkin_utilities
from . import xarkin_message_dialog
from . import xarkin_network_service
from . import xarkin_xml_exporter

global_parameters_xml = ''
global_mapping_xml = ''
global_interval_xml = ''

def get_armature_items(self, context):
    item_list = []
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

def get_mapping_items(self, context):
    item_list = []
    mappings_table = xarkin_session_data.get_mappings_table()
    mappings_bone_list_table = xarkin_session_data.get_mappings_bone_list_table()
    if (mappings_table == None):
        item_list.append(tuple([XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE]))
    else:
        current_armature_name = self.armatures_prop
        armature_bone_list = xarkin_utilities.get_armature_bone_list(current_armature_name)
        for mapping_name in mappings_table.keys():
            mapping_bone_list = mappings_bone_list_table[mapping_name]
            if (xarkin_utilities.same_string_array(mapping_bone_list, armature_bone_list)):
                item_list.append(tuple([mapping_name, mapping_name, mapping_name]))
        if (len(item_list) == 0):
            item_list.append(tuple([XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE, XAR_NO_MAPPINGS_AVAILABLE]))
    return item_list

def make_service_call():
    global global_parameters_xml
    global global_mapping_xml
    global global_interval_xml
    xarkin_network_service.cycle_capture_request(global_parameters_xml, global_mapping_xml, global_interval_xml)

class XarkinCycleCaptureDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_cycle_capture_dialog"
    bl_label = "Capture Cycle or Pose"
    bl_description = "Capture and simulate a cycle between given frame boundaries for later use"

    network_service_busy = False

    wait_and_abort_options = [("wait", "Keep Waiting...", "Keep waiting for the current operation to complete."), ("abort", "Abort", "Abandon the current operation.")]
    wait_or_abort_prop: EnumProperty(name='Actions', items=wait_and_abort_options, default=wait_and_abort_options[0][0])

    cycle_name_prop: StringProperty(name="Cycle Name", default="", description="Valid Characters are [a-z] [A-Z] [0-9] - _\nMin Length: 3")
    pose_name_prop: StringProperty(name="Pose Name", default="", description="Valid Characters are [a-z] [A-Z] [0-9] - _\nMin Length: 3")
    armatures_prop: EnumProperty(items=get_armature_items, name="Armature", default=None)
    mappings_prop: EnumProperty(items=get_mapping_items, name="Mapping", default=None)
    first_frame_prop: IntProperty(name="First Frame", default=1, min=1)
    last_frame_prop: IntProperty(name="Last Frame", default=1, min=1)
    is_walk_prop: BoolProperty(name="Walk")
    
    def draw(self, context):
        layout = self.layout
        
        if self.network_service_busy:
            layout.label(text="An operation is already in progress!")
            for option in self.wait_and_abort_options:
                row = layout.row()
                row.prop_enum(self, 'wait_or_abort_prop', option[0], text=option[1])
        else:
            col = layout.column()
            row = col.row()
            if (self.first_frame_prop == self.last_frame_prop):
                row.prop(self, 'pose_name_prop')
            else:
                row.prop(self, 'cycle_name_prop')
            row = col.row()
            row.prop(self, 'armatures_prop')
            row = col.row()
            row.prop(self, 'mappings_prop')
            row = col.row()
            row.prop(self, 'first_frame_prop')
            row = col.row()
            row.prop(self, 'last_frame_prop')
            row = col.row()
            row.prop(self, 'is_walk_prop')

    def invoke(self, context, event):
        self.network_service_busy = not xarkin_network_service.idle()

        armature_count = 0
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                armature_count = armature_count + 1
        if (armature_count == 0):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No Armatures Available')
            return  {'FINISHED'}

        subject_arm_name = xarkin_session_data.get_subject_armature_name()
        self.armatures_prop = subject_arm_name
        if (subject_arm_name != None):
            armature_obj = bpy.data.objects[self.armatures_prop]
            anim_data = armature_obj.animation_data
            if (anim_data is not None) and (anim_data.action is not None):
                last_frame = 1
                for fcurve in anim_data.action.fcurves:
                    for key_frame in fcurve.keyframe_points:
                        if key_frame.co.x > last_frame:
                            last_frame = key_frame.co.x
                self.last_frame_prop = int(last_frame)

        most_recent_mapping_name = xarkin_session_data.get_session_variable("most_recent_mapping_name")
        if (not most_recent_mapping_name == None):
            m_items = get_mapping_items(self, None)
            for item in m_items:
                if (item[1] == most_recent_mapping_name):
                    self.mappings_prop = most_recent_mapping_name

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if self.network_service_busy:
            if (self.wait_or_abort_prop == 'abort'):
                xarkin_network_service.abort()
            return {'FINISHED'}
        xarkin_session_data.set_session_variable("most_recent_armature", self.armatures_prop)
        xarkin_session_data.set_session_variable("most_recent_mapping_name", self.mappings_prop)
        if (self.mappings_prop == XAR_NO_MAPPINGS_AVAILABLE):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No mappings available.')
            return {'FINISHED'}
        first_frame = self.first_frame_prop
        last_frame = self.last_frame_prop
        if (first_frame == last_frame) and (len(self.pose_name_prop) < 3):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Pose name too short.')
            return {'FINISHED'}
        elif (last_frame > first_frame) and (len(self.cycle_name_prop) < 3):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Cycle name too short.')
            return {'FINISHED'}
        if (last_frame < first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Last Frame cannot be less than First Frame.')
            return {'FINISHED'}
        elif ((last_frame - first_frame) < 10) and (last_frame != first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='This looks like too few\nframes to contain a cycle.\n'\
                'This warning is issued if\nthe interval is greater than one frame\n(capture a pose) but less than 10 frames.')
            return {'FINISHED'}

        mapping_xml = xarkin_session_data.get_mappings_table()[self.mappings_prop]

        exporter = xarkin_xml_exporter.EditorXMLExporter()

        first_export_frame = first_frame
        last_export_frame = last_frame
        lead_buffer = 0
        trail_buffer = 0

        interval_xml = exporter.get_mogen(self.armatures_prop, first_export_frame, last_export_frame)

        parameters_xml = '<parameters>'
        parameters_xml += '<parameter name="operation" value="capture_cycle" />'
        parameters_xml += '<parameter name="armature_name" value="' + self.armatures_prop + '" />'
        parameters_xml += '<parameter name="mapping_name" value="' + self.mappings_prop + '" />'
        if last_frame == first_frame:
            parameters_xml += '<parameter name="cycle_name" value="' + self.pose_name_prop + '" />'
        else:
            parameters_xml += '<parameter name="cycle_name" value="' + self.cycle_name_prop + '" />'
        parameters_xml += '<parameter name="first_frame" value="' + str(first_frame) + '" />'
        parameters_xml += '<parameter name="last_frame" value="' + str(last_frame) + '" />'
        parameters_xml += '<parameter name="lead_buffer" value="' + str(lead_buffer) + '" />'
        parameters_xml += '<parameter name="trail_buffer" value="' + str(trail_buffer) + '" />'
        parameters_xml += '<parameter name="is_walk" value="' + str(self.is_walk_prop) + '" />'
        parameters_xml += '</parameters>'

        global global_parameters_xml
        global global_mapping_xml
        global global_interval_xml
        global_parameters_xml = parameters_xml
        global_mapping_xml = mapping_xml
        global_interval_xml = interval_xml
        thread = threading.Thread(target=make_service_call)
        thread.start()
        return {'FINISHED'}

Xarkin Animation Addon v1.0

The .zip file is the addon you'll install.  Contact us via the contact page at www.xarkinsoftware.com for a Userid and Password.

The .pdf file is a description of the addon's capabilities.

There is a useful video on the topic of mapping at  https://youtu.be/6d-wvRR6RSc

Further information can be found at www.xarkinsoftware.com.
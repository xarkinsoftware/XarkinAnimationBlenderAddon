Xarkin Animation Addon v1.0

xarkin_operations.zip file is the addon you'll install.  Contact us via the contact page at www.xarkinsoftware.com for a Userid and Password.

Xarkin.pdf file is a description of the addon's capabilities.

XarkinBlenderAddon1.0.zip is a bundling of the addon, the pdf document, and the gpl license document to make downloading simpler.

There is a useful video on the topic of mapping at  https://youtu.be/6d-wvRR6RSc

Further information can be found at www.xarkinsoftware.com.

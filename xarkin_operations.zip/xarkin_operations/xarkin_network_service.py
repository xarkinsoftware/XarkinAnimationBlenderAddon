# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_INITIATE_SESSION = 'initiate_session'
XAR_FETCH_USER_INFO = 'mogen_get_user_info_v2'
XAR_INVISIBLE_MARKER = '_fill_in_invisible'
XAR_MODIFY_WALK_OPERATION = 'modify_walk_operation'
XAR_MODIFY_RUN_OPERATION = 'modify_run_operation'
XAR_TURN_OPERATION = 'turn_operation'
XAR_APPEND_CYCLE_OPERATION = 'append_cycle_operation'
XAR_APPEND_TRANSITION_OPERATION = 'append_transition_operation'
XAR_CAPTURE_CYCLE_OPERATION = 'capture_cycle_operation'
XAR_CAPTURE_SINGLE_OPERATION = 'capture_single_operation'
XAR_CAPTURE_GESTURE_OPERATION = 'capture_gesture_operation'

XAR_CHANGE_PASSWORD = 'change_password'
XAR_INVALID_USERID_OR_PASSWORD = 'Invalid Userid or Password'
XAR_REFLECT_PAGE = 'Generated.html'
XAR_REFLECT_REQUEST = 'reflect_request'
XAR_REFLECT_MAPPING_REQUEST = 'mapping_reflect_request'
XAR_REFLECT_ACCOUNT_MANAGER_REQUEST = 'account_manager_reflect_request'
XAR_REFLECT_ELEMENT_MANAGER_REQUEST = 'element_manager_reflect_request'
XAR_REFLECT_CYCLE_EDIT_REQUEST = 'cycle_edit_reflect_request'
XAR_REFLECT_SINGLE_EDIT_REQUEST = 'single_edit_reflect_request'
XAR_REFLECT_GESTURE_EDIT_REQUEST = 'gesture_edit_reflect_request'
XAR_REFLECT_SEQUENCE_EDIT_REQUEST = 'sequence_edit_reflect_request'
XAR_REFLECT_CYCLE_DESIGN_REQUEST = 'cycle_design_reflect_request'
XAR_REFLECT_SINGLE_DESIGN_REQUEST = 'single_design_reflect_request'
XAR_REFLECT_GESTURE_DESIGN_REQUEST = 'gesture_design_reflect_request'
XAR_REFLECT_SEQUENCE_DESIGN_REQUEST = 'sequence_design_reflect_request'

XAR_MIN_PASSWORD_LENGTH = 8

XAR_STATE_IDLE = 0
XAR_STATE_REQUEST_IN_PROGRESS = 1
XAR_STATE_RESULT_AVAILABLE = 2
XAR_STATE_IMPORTING_FRAMES = 3

import bpy
import importlib
import xml.dom.minidom
import urllib
import threading
import time
import datetime
from .websocket import WebSocketApp
import webbrowser

from . import xarkin_utilities
from . import xarkin_session_data
from . import xarkin_xml_exporter
from . import xarkin_frame_importer
from . import xarkin_message_dialog
from . import xarkin_proxy

global_pk_exponent = ''
global_pk_modulus = ''

global_userid = '_no_userid_'
global_role = ''
global_password = ''
global_new_password = ''
global_request_parameters_xml = ''
global_interval_xml = ''
global_first_import_frame = -1

global_request_state = XAR_STATE_IDLE
global_request_index = 0
global_import_frame = -1

browser_counter = 0

global_arm_name = ''
global_sequence_xml = ''
global_insertion_frame = 0
global_progress_value = -1

# STATE MANAGEMENT
def show_network_response_message(message_heading, message):
    if (message_heading == None) or (message_heading == ''):
        bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg=message)
    else:
        bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg=message_heading + ':\n' + message)

def idle():
    global global_request_state
    return global_request_state == XAR_STATE_IDLE

def request_in_progress():
    global global_request_state
    return global_request_state == XAR_STATE_REQUEST_IN_PROGRESS

def result_available():
    global global_request_state
    return global_request_state == XAR_STATE_RESULT_AVAILABLE

def importing_frames():
    global global_request_state
    return global_request_state == XAR_STATE_IMPORTING_FRAMES

def abort():
    global global_request_state
    global global_request_index
    global global_import_frame
    global_request_state = XAR_STATE_IDLE
    global_request_index = global_request_index + 1
    global_import_frame = -1
    xarkin_session_data.server_result = None
    xarkin_session_data.frame_node_count = -1

# COMMON SOCKET METHODS
def on_error(ws, error):
    abort()
    bpy.app.timers.register(lambda: show_network_response_message(None, 'Xarkin server could not be reached.'), first_interval=0)
    print("WebSocket Error:" + str(error))

def on_close(ws, number, message):
    print("WebSocket Connection Closed with number " + str(number) + " and message " + str(message))

def extract_public_key(message):
    global global_pk_exponent
    global global_pk_modulus
    modulus_pos = str(message).find('pk_modulus')
    exponent_pos = str(message).find('pk_exponent')
    if (modulus_pos > 0) and (exponent_pos > 0):
        exponent_start_pos = message.find('"', exponent_pos) + 1
        exponent_end_pos = message.find('"', exponent_start_pos + 1)
        modulus_start_pos = message.find('"', modulus_pos) + 1
        modulus_end_pos = message.find('"', modulus_start_pos + 1)
        global_pk_exponent = int(message[exponent_start_pos:exponent_end_pos])
        global_pk_modulus = int(message[modulus_start_pos:modulus_end_pos])

def extract_role(message):
    global global_role
    role_pos = str(message).find('role')
    if (role_pos > 0):
        role_start_pos = message.find('"', role_pos) + 1
        role_end_pos = message.find('"', role_start_pos + 1)
        global_role = message[role_start_pos:role_end_pos]

# INITIATE SESSION
def initiate_session():
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    if (server_address.find('localhost') >= 0):
        print("Attempting connection to localhost.")
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_initiate_session_response,
                            on_error=process_initiate_session_error,
                            on_close=on_close)
    ws.on_open = send_initiate_session_request
    ws.run_forever()

def send_initiate_session_request(ws):
    global global_userid
    message = 'requested_element=' + XAR_INITIATE_SESSION\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER
    ws.send(message)

def process_initiate_session_error(ws, message):
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))
    bpy.app.timers.register(lambda: show_network_response_message(None, 'Xarkin session initiation failed.'), first_interval=0)

def process_initiate_session_response(ws, message):
    extract_public_key(message)
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))
    xarkin_session_data.fetch_user_data()

# SET USERID AND PASSWORD
def encrypt_password(password):
    global global_pk_exponent
    global global_pk_modulus
    password_int = int.from_bytes(password.encode("ascii"), "little")
    encrypted_password_int = pow(password_int, global_pk_exponent, global_pk_modulus)
    encrypted_password = str(encrypted_password_int)
    return encrypted_password

def set_user_id_and_password(userid, new_password):
    global global_userid
    global global_new_password
    global_userid = userid
    global_new_password = new_password
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_password_update_response,
                            on_error=process_password_update_response,
                            on_close=on_close)
    ws.on_open = send_password_update_request
    ws.run_forever()

def send_password_update_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_new_password
    global global_pk_exponent
    global global_pk_modulus

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    request_password = global_password
    if (request_password == ''):
        request_password = global_new_password

    encrypted_password = encrypt_password(request_password)

    encrypted_new_password = encrypt_password(global_new_password)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&encrypted_new_password=' + encrypted_new_password\
        + '&requested_element=' + XAR_CHANGE_PASSWORD
    ws.send(message)

def process_password_update_response(ws, message):
    global global_password
    global global_request_state
    global_request_state = XAR_STATE_IDLE
    if (message.startswith("<fail")):
        global_password = ''
        clear_password()
        print("Password save failed.")
        bpy.app.timers.register(lambda: show_network_response_message(None, 'Password change failed.'), first_interval=0)
    else:
        global global_userid
        global global_new_password
        global_password = global_new_password
        xarkin_session_data.save_userid_and_password_locally(global_userid, global_password)
        print("Password saved.")
        bpy.app.timers.register(lambda: show_network_response_message(None, 'Password saved.'), first_interval=0)
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

def clear_password():
    try:
        userid_filepath = xarkin_session_data.get_userid_filepath()
        with open(userid_filepath, 'r') as userid_file:
            userid_password = userid_file.read()
            line_split = userid_password.split(':')
            userid = line_split[0]
        with open(userid_filepath, 'w') as userid_file:
            userid_file.write(userid + ':')
    except Exception as exc:
        print("Failed to access userid file.")

# FETCH USER INFO
def fetch_user_info(userid, password):
    global global_userid
    global global_password
    global_userid = userid
    global_password = password
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_user_info_response,
                            on_error=process_user_info_response,
                            on_close=on_close)
    ws.on_open = send_user_info_request
    ws.run_forever()

def send_user_info_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_pk_exponent
    global global_pk_modulus

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_FETCH_USER_INFO
    ws.send(message)

def process_user_info_response(ws, message):
    global global_userid
    global global_password
    global global_request_state
    
    global_request_state = XAR_STATE_IDLE
    if (message.find(XAR_INVALID_USERID_OR_PASSWORD) >= 0):
        global_password = ''
        xarkin_session_data.save_userid_and_password_locally(global_userid, '')
        try:
            ws.close()
        except Exception as exc:
            print("WebSocket close exception\n" + str(exc))
        if (len(global_userid) == 0):
            bpy.app.timers.register(lambda: show_network_response_message(None, 'Not logged in.'), first_interval=0)
        else:
            bpy.app.timers.register(lambda: show_network_response_message(None, 'Login for ' + global_userid + ' failed.'), first_interval=0)
        return
    mappings_list = xarkin_session_data.get_mappings_list()
    cycles_list = xarkin_session_data.get_cycles_list()
    mappings_list.clear()
    cycles_list.clear()
    message_type_string = str(type(message))
    extract_role(message)
    if (message_type_string.find('ConnectionRefusedError') < 0):
        try:
            dom = xml.dom.minidom.parseString(message)
            mappings = dom.getElementsByTagName('mapping')
            for mapping in mappings:
                if (mapping.hasAttribute('display_name')):
                    mapping_name = mapping.getAttribute('display_name')
                else:
                    mapping_name = mapping.getAttribute('name')
                    print("Mapping " + mapping_name + " has no display name.")
                topology_name = mapping.getAttribute('topology')
                segment_names = [name.strip() for name in mapping.getAttribute('segment_names').split(',')]
                segment_names.sort()
                mappings_list.append([topology_name, mapping_name, segment_names])
            cycle_nodes = dom.getElementsByTagName('cycle')
            for cycle in cycle_nodes:
                if (cycle.hasAttribute('display_name')):
                    cycle_name = cycle.getAttribute('display_name')
                else:
                    cycle_name = cycle.getAttribute('name')
                    print("Cycle " + cycle_name + " has no display name.")
                topology_name = cycle.getAttribute('topology')
                cycles_list.append([topology_name, cycle_name])
        except Exception as exc:
            print("Mappings message processing error\n" + str(exc))
        bpy.app.timers.register(lambda: show_network_response_message(None,'Logged in as ' + global_userid), first_interval=0)
    else:
        print("No response to server request for mappings.")
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

# INTERVAL OPERATION
def interval_service_request(request_element, request_parameters_xml, interval_xml):
    global global_request_parameters_xml
    global global_interval_xml
    global_request_parameters_xml = request_parameters_xml
    global_interval_xml = interval_xml
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_interval_operation_response,
                            on_error=on_error,
                            on_close=on_close)
    ws.request_element = request_element
    ws.on_open = send_interval_operation_request
    ws.run_forever()

def send_interval_operation_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_request_parameters_xml
    global global_interval_xml
    global global_pk_exponent
    global global_pk_modulus

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_parameters = urllib.parse.quote(global_request_parameters_xml)
    encoded_interval = urllib.parse.quote(global_interval_xml)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + ws.request_element\
        + '&request_index=' + str(global_request_index)\
        + '&request_parameters=' + encoded_parameters\
        + '&interval=' + encoded_interval
    ws.send(message)

def process_interval_operation_response(ws, message):
    extract_public_key(message)
    global global_request_state
    global global_request_index
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Interval Operation', response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                xarkin_session_data.set_server_result(message)
                global_request_state = XAR_STATE_RESULT_AVAILABLE
                bpy.app.timers.register(lambda: show_network_response_message(None, 'Operation Results Available'), first_interval=0)
            else:
                print("Response ignored because index " + str(request_index) + " doesn't match expected " + str(global_request_index))
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    if (ws != None):
        try:
            ws.close()
        except Exception as exc:
            print("WebSocket close exception\n" + str(exc))

# CAPTURE
def cycle_capture_request(request_parameters_xml, interval_xml):
    global global_request_parameters_xml
    global global_interval_xml
    global_request_parameters_xml = request_parameters_xml
    global_interval_xml = interval_xml
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_cycle_capture_response,
                            on_error=on_error,
                            on_close=on_close)
    ws.on_open = send_cycle_capture_request
    ws.run_forever()

def send_cycle_capture_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_request_parameters_xml
    global global_interval_xml
    global global_pk_exponent
    global global_pk_modulus

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_parameters = urllib.parse.quote(global_request_parameters_xml)
    encoded_interval = urllib.parse.quote(global_interval_xml)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_CAPTURE_CYCLE_OPERATION\
        + '&request_index=' + str(global_request_index)\
        + '&request_parameters=' + encoded_parameters\
        + '&interval=' + encoded_interval
    ws.send(message)

def process_cycle_capture_response(ws, message):
    extract_public_key(message)
    global global_request_parameters_xml
    global global_request_state
    global global_request_index
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Cycle Capture', response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                message_dom = xml.dom.minidom.parseString(message)
                cycle_node = message_dom.getElementsByTagName('mogen')[0]
                if cycle_node.hasAttribute('display_name'):
                    cycle_name = cycle_node.getAttribute('display_name')
                else:
                    cycle_name = cycle_node.getAttribute('name')
                    print("Cycle " + cycle_name + " has no display name.")
                assembly_node = message_dom.getElementsByTagName('assembly')[0]
                cycle_topology = assembly_node.getAttribute('topology')
                cycles_list = xarkin_session_data.get_cycles_list()
                cycles_list.append([cycle_topology, cycle_name])
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Cycle Capture', 'Cycle successfully saved.'), first_interval=0)
            else:
                print("Response ignored because index " + str(request_index) + " doesn't match expected " + str(global_request_index))
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

def single_capture_request(request_parameters_xml, interval_xml):
    global global_request_parameters_xml
    global global_interval_xml
    global_request_parameters_xml = request_parameters_xml
    global_interval_xml = interval_xml
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_single_capture_response,
                            on_error=on_error,
                            on_close=on_close)
    ws.on_open = send_single_capture_request
    ws.run_forever()

def send_single_capture_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_request_parameters_xml
    global global_interval_xml
    global global_pk_exponent
    global global_pk_modulus

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_parameters = urllib.parse.quote(global_request_parameters_xml)
    encoded_interval = urllib.parse.quote(global_interval_xml)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_CAPTURE_SINGLE_OPERATION\
        + '&request_index=' + str(global_request_index)\
        + '&request_parameters=' + encoded_parameters\
        + '&interval=' + encoded_interval
    ws.send(message)

def process_single_capture_response(ws, message):
    extract_public_key(message)
    global global_request_parameters_xml
    global global_request_state
    global global_request_index
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Single Capture', response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                message_dom = xml.dom.minidom.parseString(message)
                single_node = message_dom.getElementsByTagName('mogen')[0]
                if single_node.hasAttribute('display_name'):
                    single_name = single_node.getAttribute('display_name')
                else:
                    single_name = single_node.getAttribute('name')
                    print("Single " + single_name + " has no display name.")
                assembly_node = message_dom.getElementsByTagName('assembly')[0]
                single_topology = assembly_node.getAttribute('topology')
                singles_list = xarkin_session_data.get_singles_list()
                singles_list.append([single_topology, single_name])
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Single Capture', 'Single successfully saved.'), first_interval=0)
            else:
                print("Response ignored because index " + str(request_index) + " doesn't match expected " + str(global_request_index))
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

def gesture_capture_request(request_parameters_xml, interval_xml):
    global global_request_parameters_xml
    global global_interval_xml
    global_request_parameters_xml = request_parameters_xml
    global_interval_xml = interval_xml
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_gesture_capture_response,
                            on_error=on_error,
                            on_close=on_close)
    ws.on_open = send_gesture_capture_request
    ws.run_forever()

def send_gesture_capture_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password
    global global_request_parameters_xml
    global global_interval_xml
    global global_pk_exponent
    global global_pk_modulus

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_parameters = urllib.parse.quote(global_request_parameters_xml)
    encoded_interval = urllib.parse.quote(global_interval_xml)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_CAPTURE_GESTURE_OPERATION\
        + '&request_index=' + str(global_request_index)\
        + '&request_parameters=' + encoded_parameters\
        + '&interval=' + encoded_interval
    ws.send(message)

def process_gesture_capture_response(ws, message):
    extract_public_key(message)
    global global_request_parameters_xml
    global global_request_state
    global global_request_index
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Gesture Capture', response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                message_dom = xml.dom.minidom.parseString(message)
                gesture_node = message_dom.getElementsByTagName('mogen')[0]
                if gesture_node.hasAttribute('display_name'):
                    gesture_name = gesture_node.getAttribute('display_name')
                else:
                    gesture_name = gesture_node.getAttribute('name')
                    print("Gesture " + gesture_name + " has no display name.")
                assembly_node = message_dom.getElementsByTagName('assembly')[0]
                gesture_topology = assembly_node.getAttribute('topology')
                gestures_list = xarkin_session_data.get_gestures_list()
                gestures_list.append([gesture_topology, gesture_name])
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message('Gesture Capture', 'Gesture successfully saved.'), first_interval=0)
            else:
                print("Response ignored because index " + str(request_index) + " doesn't match expected " + str(global_request_index))
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

# IMPORT
def get_import_armature_name():
    global global_request_parameters_xml
    if (global_request_parameters_xml == None):
        return None
    try:
        arm_name = None
        request_dom = xml.dom.minidom.parseString(global_request_parameters_xml)
        parameter_nodes = request_dom.getElementsByTagName("parameter")
        for parameter_node in parameter_nodes:
            parameter_name = parameter_node.getAttribute('name')
            if (parameter_name == 'armature_name'):
                arm_name = parameter_node.getAttribute('value')
        return arm_name
    except:
        return None

def get_number_of_import_frames():
    if (xarkin_session_data.frame_node_count == -1):
        return None
    return xarkin_session_data.frame_node_count

def initiate_import():
    global global_request_state
    global global_import_frame
    global global_request_parameters_xml
    global global_arm_name
    global global_sequence_xml
    global global_insertion_frame
    global global_progress_value
    global global_first_import_frame

    global_import_frame = 0
    global_request_state = XAR_STATE_IMPORTING_FRAMES
    
    try:
        request_dom = xml.dom.minidom.parseString(global_request_parameters_xml)
    except:
        bpy.app.timers.register(lambda: show_network_response_message('Sequence Import', 'Sequence import failed.'), first_interval=0)
        return False

    parameter_nodes = request_dom.getElementsByTagName("parameter")
    for parameter_node in parameter_nodes:
        parameter_name = parameter_node.getAttribute('name')
        if (parameter_name == 'armature_name'):
            arm_name = parameter_node.getAttribute('value')
        if (parameter_name == 'first_frame'):
            first_frame = int(parameter_node.getAttribute('value'))

    global_arm_name = arm_name
    global_sequence_xml = xarkin_session_data.server_result
    global_insertion_frame = first_frame
    xarkin_frame_importer.current_import_frame = -1
    global_progress_value = -1
    global_first_import_frame = -1
    bpy.app.timers.register(launch_frame_importer, first_interval=0)

def launch_frame_importer():
    global global_arm_name
    global global_sequence_xml
    global global_insertion_frame
    arm_name = global_arm_name
    sequence_xml = global_sequence_xml
    first_frame = global_insertion_frame
    xarkin_frame_importer.initiate_frames_import(arm_name, sequence_xml, first_frame)
    abort()

#reflect html
def reflect_mapping(sequence_xml):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)
    ws.xml = sequence_xml
    ws.on_open = send_mapping_reflect_request
    ws.run_forever()

def send_mapping_reflect_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_xml = urllib.parse.quote(ws.xml)
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_MAPPING_REQUEST\
        + '&xml=' + encoded_xml
    ws.send(message)

def reflect_cycle_editor(interval_xml, is_cycle_str, is_walk_str, topology, mapping_name):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]

    ws.interval_xml = interval_xml
    ws.is_cycle_str = is_cycle_str
    ws.is_walk_str = is_walk_str
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_cycle_editor_reflect_request
    ws.run_forever()

def send_cycle_editor_reflect_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    is_cycle = ws.is_cycle_str
    is_walk = ws.is_walk_str
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_CYCLE_EDIT_REQUEST\
        + '&interval=' + encoded_interval\
        + '&sequence_is_cycle=' + is_cycle\
        + '&sequence_is_walk=' + is_walk\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

def reflect_single_editor(interval_xml, is_cycle_str, topology, mapping_name):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]

    ws.interval_xml = interval_xml
    ws.is_cycle_str = is_cycle_str
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_single_editor_reflect_request
    ws.run_forever()

def send_single_editor_reflect_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    is_cycle = ws.is_cycle_str
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_SINGLE_EDIT_REQUEST\
        + '&interval=' + encoded_interval\
        + '&sequence_is_cycle=' + is_cycle\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

def reflect_gesture_editor(interval_xml, is_cycle_str, topology, mapping_name):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]

    ws.interval_xml = interval_xml
    ws.is_cycle_str = is_cycle_str
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_gesture_editor_reflect_request
    ws.run_forever()

def send_gesture_editor_reflect_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    is_cycle = ws.is_cycle_str
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_GESTURE_EDIT_REQUEST\
        + '&interval=' + encoded_interval\
        + '&sequence_is_cycle=' + is_cycle\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

def reflect_cycle_design(interval_xml, topology, mapping_name):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]

    ws.interval_xml = interval_xml
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_cycle_design_reflect_request
    ws.run_forever()

def send_cycle_design_reflect_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_CYCLE_DESIGN_REQUEST\
        + '&interval=' + encoded_interval\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

def reflect_single_design(interval_xml, topology, mapping_name):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]

    ws.interval_xml = interval_xml
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_single_design_reflect_request
    ws.run_forever()

def send_single_design_reflect_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_SINGLE_DESIGN_REQUEST\
        + '&interval=' + encoded_interval\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

def reflect_gesture_design(interval_xml, topology, mapping_name):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]

    ws.interval_xml = interval_xml
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_gesture_design_reflect_request
    ws.run_forever()

def send_gesture_design_reflect_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_GESTURE_DESIGN_REQUEST\
        + '&interval=' + encoded_interval\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

def reflect_account_manager():
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    ws.on_open = send_account_manager_request
    ws.run_forever()

def send_account_manager_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_ACCOUNT_MANAGER_REQUEST
    ws.send(message)

def reflect_element_manager():
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    ws.on_open = send_element_manager_request
    ws.run_forever()

def send_element_manager_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&requested_element=' + XAR_REFLECT_ELEMENT_MANAGER_REQUEST
    ws.send(message)

def process_reflect_response(ws, message):
    extract_public_key(message)
    global global_request_parameters_xml
    global global_request_state
    global global_request_index
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message(None, response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            global_request_state = XAR_STATE_IDLE
            server_address = xarkin_session_data.fetch_config_parameter('remote_server')
            web_page_address = str("https://" + server_address + "/" + XAR_REFLECT_PAGE + '?id=' + message)
            webbrowser.open(web_page_address, new=1)
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

def on_reflect_error(ws, error):
    bpy.app.timers.register(lambda: show_network_response_message(None, 'Xarkin server could not be reached.'), first_interval=0)
    print("WebSocket Reflect Error:" + str(error))

# LOCAL PROXY STUDIO REFLECTION
def reflect_sequence_edit_through_proxy(interval_xml, is_cycle_str, is_walk_str, topology, mapping_name, armature_name, first_frame):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    server_name, server_port = server_address.split(':')
    xarkin_proxy.remote_server = server_name
    xarkin_proxy.remote_port = int(server_port)
    xarkin_proxy.armature_name = armature_name
    xarkin_proxy.first_frame = first_frame

    try:
        proxy_thread = threading.Thread(target=xarkin_proxy.open_server)
        proxy_thread.daemon = True
        proxy_thread.start()
    except Exception as exc:
        print("Exception starting proxy server\n" + str(exc))

    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_through_proxy_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]


    ws.interval_xml = interval_xml
    ws.is_cycle_str = is_cycle_str
    ws.is_walk_str = is_walk_str
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_sequence_edit_reflect_through_proxy_request
    ws.run_forever()

def send_sequence_edit_reflect_through_proxy_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    is_cycle = ws.is_cycle_str
    is_walk = ws.is_walk_str
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&host_name=' + xarkin_session_data.XAR_HOST_NAME\
        + '&requested_element=' + XAR_REFLECT_SEQUENCE_EDIT_REQUEST\
        + '&interval=' + encoded_interval\
        + '&sequence_is_cycle=' + is_cycle\
        + '&sequence_is_walk=' + is_walk\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

def process_reflect_through_proxy_response(ws, message):
    extract_public_key(message)
    global global_request_parameters_xml
    global global_request_state
    global global_request_index
    if global_request_state == XAR_STATE_REQUEST_IN_PROGRESS:
        if len(message) == 0:
            print("process_interval_operation_response NO MESSAGE RECEIVED")
        elif message.startswith('<fail'):
            request_index = xarkin_utilities.extract_request_index(message)
            if (request_index == global_request_index):
                response_note = xarkin_utilities.extract_response_note(message)
                print("Received fail response: " + response_note)
                global_request_state = XAR_STATE_IDLE
                bpy.app.timers.register(lambda: show_network_response_message(None, response_note), first_interval=0)
            else:
                print("Ignoring fail response: " + message)
        else:
            global_request_state = XAR_STATE_IDLE
            web_page_address = str("http://localhost:" + str(xarkin_proxy.local_port) + "/" + XAR_REFLECT_PAGE + '?id=' + message)
            webbrowser.open(web_page_address, new=1)
    elif global_request_state == XAR_STATE_IDLE:
        print("Response ignored because request state is idle. (Request was cancelled.)")
    elif global_request_state == XAR_STATE_RESULT_AVAILABLE:
        print("Response ignored because previous result has not been processed. (Inconsistent state!)")
    elif global_request_state == XAR_STATE_IMPORTING_FRAMES:
        print("Response ignored because previous result is still being processed. (Inconsistent state!)")
    else:
        print("Response ignored because request state is unknown " + str(global_request_state))
    try:
        ws.close()
    except Exception as exc:
        print("WebSocket close exception\n" + str(exc))

def reflect_sequence_design_through_proxy(interval_xml, topology, mapping_name, armature_name, first_frame, last_frame):
    server_address = xarkin_session_data.fetch_config_parameter('remote_server')
    server_name, server_port = server_address.split(':')
    xarkin_proxy.remote_server = server_name
    xarkin_proxy.remote_port = int(server_port)
    xarkin_proxy.armature_name = armature_name
    xarkin_proxy.first_frame = first_frame

    try:
        proxy_thread = threading.Thread(target=xarkin_proxy.open_server)
        proxy_thread.daemon = True
        proxy_thread.start()
    except Exception as exc:
        print("Exception starting proxy server\n" + str(exc))

    web_socket_address = "wss://" + server_address
    ws = WebSocketApp(web_socket_address,
                            on_message=process_reflect_through_proxy_response,
                            on_error=on_reflect_error,
                            on_close=on_close)

    if (topology == ''):
        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == mapping_name):
                topology = mapping_list[mapping_index][0]


    ws.interval_xml = interval_xml
    ws.topology = topology
    ws.mapping_name = mapping_name
    ws.on_open = send_sequence_design_reflect_through_proxy_request
    ws.run_forever()

def send_sequence_design_reflect_through_proxy_request(ws):
    global global_request_state
    global global_request_index
    global global_userid
    global global_password

    global_request_state = XAR_STATE_REQUEST_IN_PROGRESS
    global_request_index = global_request_index + 1

    encrypted_password = encrypt_password(global_password)

    encoded_interval = urllib.parse.quote(ws.interval_xml)
    topology = ws.topology
    message = 'user_id=' + global_userid\
        + '&encrypted_password=' + encrypted_password\
        + '&request_index=' + str(global_request_index)\
        + '&build_number=' + xarkin_session_data.XAR_BUILD_NUMBER\
        + '&host_name=' + xarkin_session_data.XAR_HOST_NAME\
        + '&requested_element=' + XAR_REFLECT_SEQUENCE_DESIGN_REQUEST\
        + '&interval=' + encoded_interval\
        + '&topology=' + topology\
        + '&mapping_name=' + ws.mapping_name
    ws.send(message)

        # + '&sequence_is_cycle=' + is_cycle\
        # + '&sequence_is_walk=' + is_walk\

# GUI Assistance
def get_mapping_items(self, context):
    armature_name = self.armatures_prop
    mappings_list = xarkin_session_data.session_data[xarkin_session_data.XAR_MAPPINGS_DATA]
    item_list = xarkin_utilities.get_valid_mapping_items(armature_name, mappings_list)
    return item_list

def get_mapping_source_items(self, context):
    global global_userid
    armature_name = self.armatures_prop
    mappings_list = xarkin_session_data.session_data[xarkin_session_data.XAR_MAPPINGS_DATA]
    item_list = xarkin_utilities.get_valid_source_items(armature_name, mappings_list, global_userid)
    return item_list

def get_mapping_name_items(self, context):
    armature_name = self.armatures_prop
    source_name = self.mapping_source_prop
    mappings_list = xarkin_session_data.session_data[xarkin_session_data.XAR_MAPPINGS_DATA]
    item_list = xarkin_utilities.get_valid_name_items(armature_name, mappings_list, source_name, None)
    return item_list

def get_cycle_source_items(self, context):
    global global_userid
    armature_name = self.armatures_prop
    cycles_list = xarkin_session_data.session_data[xarkin_session_data.XAR_CYCLES_DATA]
    item_list = xarkin_utilities.get_valid_source_items(armature_name, cycles_list, global_userid)
    return item_list

def get_sole_cycle_name_items(self, context):
    cycle_source_name = self.cycle_source_prop
    return get_qualified_cycle_name(self, cycle_source_name)

def get_from_cycle_name_items(self, context):
    cycle_source_name = self.from_cycle_source_prop
    return get_qualified_cycle_name(self, cycle_source_name)

def get_to_cycle_name_items(self, context):
    cycle_source_name = self.to_cycle_source_prop
    return get_qualified_cycle_name(self, cycle_source_name)

def get_qualified_cycle_name(self, cycle_source_name):
    armature_name = self.armatures_prop

    whole_mapping_name = self.mapping_name_prop
    if (self.mapping_source_prop != xarkin_utilities.XAR_STANDARD_NAME):
        whole_mapping_name = self.mapping_source_prop + ':' + self.mapping_name_prop
    mappings_list = xarkin_session_data.session_data[xarkin_session_data.XAR_MAPPINGS_DATA]
    mapping_topology = "unknown"
    for mapping in mappings_list:
        if (mapping[1] == whole_mapping_name):
            mapping_topology = mapping[0]

    cycles_list = xarkin_session_data.session_data[xarkin_session_data.XAR_CYCLES_DATA]
    item_list = xarkin_utilities.get_valid_name_items(armature_name, cycles_list, cycle_source_name, mapping_topology)
    return item_list


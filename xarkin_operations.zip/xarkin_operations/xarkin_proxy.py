import bpy
import os
import sys
import time
import socket
import requests
import mimetypes
import warnings
import threading
import base64
import hashlib
import struct
import ssl
import binascii
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from . import xarkin_network_service

XAR_DEFAULT_BUFFER_SIZE = 1024
XAR_MAXIMUM_BUFFER_SIZE = 20000000
XAR_SOCKET_TIMEOUT = 5
XAR_HB_TIMEOUT = 5

warnings.filterwarnings("ignore", category=InsecureRequestWarning)
exit_flag = threading.Event()
remote_server = ''
remote_port = 0
local_port = 0
armature_name = 'unassigned'
first_frame = -1
hb_time = 0

def set_exit_flag():
    print("set_exit_flag")
    exit_flag.set()

def hb_timeout():
    global hb_time
    if (hb_time == 0):
        return False
    curr_time = int(time.time())
    return ((curr_time - hb_time) > XAR_HB_TIMEOUT)

def open_server():
    global hb_time
    global local_port
    global exit_flag
    server_address = ('127.0.0.1', 0)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(server_address)
    local_port = server_socket.getsockname()[1]
    print("Localhost server listening on port " + str(local_port))
    server_socket.settimeout(XAR_SOCKET_TIMEOUT)
    server_socket.listen()
    try:
        while (not exit_flag.is_set()) and (not hb_timeout()):
            try:
                client_socket, client_address = server_socket.accept()
                client_thread = threading.Thread(target=handle_request, args=(client_socket,))
                client_thread.daemon = True
                client_thread.start()
            except socket.timeout:
                pass
    finally:
        server_socket.close()
    hb_time = 0
    print("Exiting localhost server on port " + str(local_port))

def handle_request(client_socket):
    request_bytes = b""
    while ((b"\r\n\r\n" not in request_bytes) and (len(request_bytes) < XAR_MAXIMUM_BUFFER_SIZE)):
        next_block = client_socket.recv(XAR_DEFAULT_BUFFER_SIZE)
        if not next_block:
            break
        request_bytes += next_block
    if (len(request_bytes) >= XAR_MAXIMUM_BUFFER_SIZE):
        print("Request packet too large " + str(len(request_bytes)))
        client_socket.close()
        return
    if (b"Sec-WebSocket-Key:" in request_bytes):
        handle_websocket_call(client_socket, request_bytes)
    else:
        handle_http_get(client_socket, request_bytes)

def handle_http_get(client_socket, request_bytes):
    global remote_server
    global remote_port
    request = request_bytes.decode('utf-8')
    request_split = request.split()
    if ((request_split == None) or (len(request_split) < 2)):
        return
    path = request_split[1]
    remote_url = 'https://' + remote_server + ':' + str(remote_port) + path
    try:
        response = requests.get(remote_url, verify=False)
        content_type_subject = path
        if (len(path.split('?')) > 1):
            content_type_subject = path.split('?')[0]
        content_type, _ = mimetypes.guess_type(content_type_subject)
        if content_type is None:
            content_type = "application/octet-stream"
        header_str = "HTTP/1.1 200 OK\r\nContent-Type: " + content_type + "\r\nContent-Length: " + str(len(response.content)) + "\r\n\r\n"
        header_bytes = header_str.encode('utf-8')
        client_socket.sendall(header_bytes + response.content)
    except Exception as exc:
        http_response = "HTTP/1.1 404 Not Found\r\nContent-type: text/plain\r\n\r\nPage not found".encode('utf-8')
        client_socket.sendall(http_response)
    finally:
        client_socket.close()

def perform_handshake(sock, host, port):
    key = base64.b64encode(os.urandom(16)).decode("utf-8")
    handshake_request = (
        f"GET / HTTP/1.1\r\n"
        f"Host: {host}:{port}\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {key}\r\n"
        "Sec-WebSocket-Version: 13\r\n"
        "\r\n"
    )
    sock.send(handshake_request.encode("utf-8"))
    handshake_response = sock.recv(4096).decode("utf-8")
    if (" 101 Switching Protocols" not in handshake_response):
        raise Exception("WebSocket handshake failed")

def handle_websocket_handshake(client_socket, request_bytes):
    headers, _, body = request_bytes.partition(b"\r\n\r\n")
    key = headers.split(b"Sec-WebSocket-Key: ")[1].split(b"\r\n")[0].strip()
    accept_key = base64.b64encode(hashlib.sha1(key + b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").digest())
    handshake = (
        b"HTTP/1.1 101 Switching Protocols\r\n"
        b"Upgrade: websocket\r\n"
        b"Connection: Upgrade\r\n"
        b"Sec-WebSocket-Accept: " + accept_key + b"\r\n\r\n"
    )
    client_socket.sendall(handshake)

def handle_websocket_call(client_socket, request_bytes):
    global hb_time
    global remote_server
    global remote_port
    global armature_name
    global first_frame
    handle_websocket_handshake(client_socket, request_bytes)
    client_data_str = receive_websocket_string(client_socket)
    if (client_data_str.find('&requested_element=heart_beat') >= 0):
        hb_time = int(time.time())
        send_websocket_string(client_socket, '<ack/>')
        client_socket.close()
        return
    with socket.create_connection((remote_server, remote_port)) as remote_socket:
        if (remote_server == 'localhost'):
            remote_socket = ssl.wrap_socket(remote_socket, ssl_version=ssl.PROTOCOL_TLS, cert_reqs=ssl.CERT_NONE)
        else:
            remote_socket = ssl.wrap_socket(remote_socket, ssl_version=ssl.PROTOCOL_TLS)
        perform_handshake(remote_socket, remote_server, remote_port)
        send_websocket_string(remote_socket, client_data_str)
        server_data_str = receive_websocket_string(remote_socket)
    if (client_data_str.find('&requested_element=transfer_interval') >= 0):
        xarkin_network_service.abort()
        xarkin_network_service.global_request_state = xarkin_network_service.XAR_STATE_REQUEST_IN_PROGRESS
        xarkin_network_service.global_first_import_frame = first_frame
        xarkin_network_service.global_request_parameters_xml = '<parameters><parameter name="armature_name" value="' + armature_name + '" />'\
            + '<parameter name="first_frame" value="' + str(first_frame) + '" /></parameters>'
        index_of_mogen = server_data_str.find('<mogen')
        if (index_of_mogen >= 0):
            sequence_xml = server_data_str[:index_of_mogen] + '<mogen request_index="' + str(xarkin_network_service.global_request_index) + '" '\
                + server_data_str[index_of_mogen + len('<mogen'):]
            xarkin_network_service.process_interval_operation_response(None, sequence_xml)
            server_data_str = '<success/>'
        else:
            server_data_str = '<fail/>'


    send_websocket_string(client_socket, server_data_str)
    client_socket.close()
    remote_socket.close()

def receive_websocket_string(sock):
    frame_counter = 0
    complete_message = b''
    while True:
        frame_counter += 1
        header = sock.recv(2)
        if not header:
            break
        fin = (header[0] & 0x80) != 0
        opcode = header[0] & 0x0F
        payload_length = header[1] & 0x7F
        if payload_length == 126:
            payload_length = int.from_bytes(sock.recv(2), byteorder="big")
        elif payload_length == 127:
            payload_length = int.from_bytes(sock.recv(8), byteorder="big")
        if (header[1] & 0x80) != 0:
            mask = sock.recv(4)
        payload = b''
        while (len(payload) < payload_length):
            partial_payload = sock.recv(payload_length - len(payload))
            payload = payload + partial_payload
        decoded_payload = bytearray(payload)
        if (header[1] & 0x80) != 0:
            for i in range(len(payload)):
                decoded_payload[i] ^= mask[i % 4]
        complete_message = complete_message + decoded_payload
        if fin:
            break
    utf8_string = complete_message.decode("utf-8")
    return utf8_string

def send_websocket_string(sock, data_str):
    data = data_str.encode('utf-8')
    header = struct.pack('>B', 0b10000000 | 1)
    sock.sendall(header)
    if len(data) <= 125:
        sock.sendall(struct.pack('>B', len(data)))
    elif len(data) <= 65535:
        sock.sendall(struct.pack('>BH', 126, len(data)))
    else:
        sock.sendall(struct.pack('>BQ', 127, len(data)))
    sock.sendall(data)

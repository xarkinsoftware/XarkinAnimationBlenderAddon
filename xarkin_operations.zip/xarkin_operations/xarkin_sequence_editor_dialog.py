# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_STUDIO_TEMPLATE_FILEPATH = '/addons/xarkin_common/web_common/Studio.html'
XAR_REMOTE_SERVER_MARKER = '__REMOTE__SERVER__MARKER__'
XAR_USERID_MARKER = '__USERID__MARKER__'
XAR_PASSWORD_MARKER = '__PASSWORD__MARKER__'
XAR_MAPPING_MARKER = '__MAPPING__MARKER__'
XAR_SEQUENCE_MARKER = '__FOREIGN__SEQUENCE__MARKER__'

import bpy
import importlib
import urllib
import time
import threading
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty
        )
from . import xarkin_session_data
from . import xarkin_utilities
from . import xarkin_message_dialog
from . import xarkin_network_service
from . import xarkin_xml_exporter

def get_topology_items(self, context):
    item_list = []
    humanoid_item = ['humanoid', 'Humanoid', 'Humanoid']
    item_list.append(tuple(humanoid_item))
    return item_list

def get_armature_items(self, context):
    item_list = []
    blank_item = ['blank', '<empty studio>', 'No Armature: Launch Empty Studio']
    item_list.append(tuple(blank_item))
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

class XarkinSequenceEditorDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_sequence_editor_dialog"
    bl_label = "Launch Sequence Editor"
    bl_description = "Launches the browser-based Sequence Editor"

    network_service_busy = False

    wait_and_abort_options = [("wait", "Keep Waiting...", "Keep waiting for the current operation to complete."), ("abort", "Abort", "Abandon the current operation.")]
    wait_or_abort_prop: EnumProperty(name='Actions', items=wait_and_abort_options, default=wait_and_abort_options[0][0])
    armatures_prop: EnumProperty(items=get_armature_items, name="", default=None)
    mapping_source_prop: EnumProperty(items=xarkin_network_service.get_mapping_source_items, name="", default=None)
    mapping_name_prop: EnumProperty(items=xarkin_network_service.get_mapping_name_items, name="", default=None)
    topologies_prop: EnumProperty(items=get_topology_items, name="", default=None)
    first_frame_prop: IntProperty(name="First Frame", default=1, min=1)
    last_frame_prop: IntProperty(name="Last Affected", default=1, min=1)
    is_walk_prop: BoolProperty(name="Walk", default=False);
    
    def draw(self, context):
        layout = self.layout

        if self.network_service_busy:
            layout.label(text="An operation is already in progress!")
            for option in self.wait_and_abort_options:
                layout.prop_enum(self, 'wait_or_abort_prop', option[0], text=option[1])
        else:
            armature_count = 0
            for x in bpy.data.objects:
                if (str(x.type) == 'ARMATURE'):
                    armature_count = armature_count + 1
            if ((armature_count == 0) or (self.armatures_prop == 'blank')):
                row1 = layout.row()
                split1 = row1.split(factor=0.285)
                split1.label(text="Armature")
                split1.prop(self, 'armatures_prop')

                row2 = layout.row()
                split2 = row2.split(factor=0.285)
                split2.label(text="Topology")
                split2.prop(self, 'topologies_prop')
            else:
                row1 = layout.row()
                split1 = row1.split(factor=0.285)
                split1.label(text="Armature")
                split1.prop(self, 'armatures_prop')

                row2 = layout.row()
                split2 = row2.split(factor=0.65)
                src2_split = split2.split(factor=0.46154)
                src2_split.label(text='Mapping')
                src2_split.prop(self, 'mapping_source_prop')
                split2.prop(self, 'mapping_name_prop')
                
                row3 = layout.row()
                split3 = row3.split(factor=0.285)
                split3.label(text="First Frame")
                split3.prop(self, 'first_frame_prop')

                row4 = layout.row()
                split4 = row4.split(factor=0.285)
                split4.label(text="Last Affected")
                split4.prop(self, 'last_frame_prop')

                layout.prop(self, 'is_walk_prop')

    def invoke(self, context, event):
        self.network_service_busy = not xarkin_network_service.idle()
        subject_arm_name = xarkin_session_data.get_subject_armature_name()
        if (subject_arm_name != None):
            self.armatures_prop = subject_arm_name
            armature_obj = bpy.data.objects[self.armatures_prop]
            anim_data = armature_obj.animation_data
            if (anim_data is not None) and (anim_data.action is not None):
                last_frame = 1
                for fcurve in anim_data.action.fcurves:
                    for key_frame in fcurve.keyframe_points:
                        if key_frame.co.x > last_frame:
                            last_frame = key_frame.co.x
                self.last_frame_prop = int(last_frame)

        self.first_frame_prop = min(int(self.last_frame_prop), bpy.context.scene.frame_current)

        most_recent_mapping_name = xarkin_session_data.get_session_variable("most_recent_mapping_name")
        if (not most_recent_mapping_name == None):
            m_items = xarkin_network_service.get_mapping_items(self, None)
            for item in m_items:
                if (item[1] == most_recent_mapping_name) or (('Standard:' + item[1]) == most_recent_mapping_name):
                    colon_pos = most_recent_mapping_name.find(':')
                    map_src = most_recent_mapping_name[0:colon_pos]
                    map_nam = most_recent_mapping_name[colon_pos + 1:]
                    self.mapping_source_prop = map_src
                    self.mapping_name_prop = map_nam

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if self.network_service_busy:
            if (self.wait_or_abort_prop == 'abort'):
                xarkin_network_service.abort()
            return {'FINISHED'}

        if (self.armatures_prop == 'blank'):    # blank is not an option
            interval_xml = ''
            is_cycle_str = 'False'
            is_walk_str = 'False'
            topology_name = self.topologies_prop
            mapping_name = ''
            first_frame = -1
            last_frame = -1
        else:
            xarkin_session_data.set_session_variable("most_recent_armature", self.armatures_prop)
            xarkin_session_data.set_session_variable("most_recent_mapping_name", self.mapping_source_prop + ':' + self.mapping_name_prop)
            if (self.mapping_source_prop == xarkin_utilities.XAR_NONE):
                bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No mappings for this character.\nPlease create one before attempting operations.')
                return {'FINISHED'}
            first_frame = self.first_frame_prop
            last_frame = self.last_frame_prop
            if (last_frame < first_frame):
                bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Last Frame must be greater than or equal to First Frame.')
                return {'FINISHED'}
            is_cycle_str = 'False'
            is_walk_str = str(self.is_walk_prop)

            exporter = xarkin_xml_exporter.EditorXMLExporter()
            interval_xml = exporter.get_mogen(self.armatures_prop, first_frame, last_frame)
            topology_name = ''
            mapping_name = self.mapping_name_prop
            if (not(self.mapping_source_prop == 'Standard')):
                mapping_name = self.mapping_source_prop + ':' + self.mapping_name_prop

        xarkin_network_service.reflect_sequence_edit_through_proxy(interval_xml, is_cycle_str, is_walk_str, topology_name, mapping_name, self.armatures_prop, first_frame)
        return {'FINISHED'}

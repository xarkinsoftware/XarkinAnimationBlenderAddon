# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

XAR_BUILD_NUMBER = '2024.04.09.638482351871583090'
XAR_HOST_NAME = 'Blender'

XAR_ENCRYPTION = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_!@#$%^&*'
XAR_SESSION_DATA = 'XarkinSessionData'
XAR_APP_DATA_DIRECTORY = 'XarkinMocapStudioUserData'
XAR_USERID_FILENAME = 'udef.txt'
XAR_CONFIG_FILENAME = 'config.txt'
XAR_MAPPINGS_DIRECTORY = "skeleton_mappings"

XAR_MAPPINGS_DATA = 'mappings_data'
XAR_CYCLES_DATA = 'cycles_data'

import bpy
import importlib
import os
from os import walk
import xml.dom.minidom
import threading
import pathlib
import time
from pathlib import Path

from . import xarkin_network_service
from . import xarkin_frame_importer

server_result = None
frame_node_count = -1
session_data = {}

def get_session_variable(element_name):
    if (session_data == None):
        print("Session map doesn't exist when trying to retrieve " + element_name)
        return None
    if (element_name in session_data):
        return session_data[element_name]
    return None

def set_session_variable(element_name, element_value):
    if (session_data == None):
        print("Session map doesn't exist when trying to save " + element_name)
        return None
    session_data[element_name] = element_value

def get_userid_filepath():
    roaming_dir = Path().home() / 'AppData' / 'Roaming'
    userid_filename = XAR_APP_DATA_DIRECTORY + '/' + XAR_USERID_FILENAME
    userid_filepath = bpy.path.abspath(f"{roaming_dir}/{userid_filename}")
    return userid_filepath

def encrypt_password(given_password):
    encrypted_password = ''
    for c in given_password:
        encrypted_password = encrypted_password + XAR_ENCRYPTION[len(XAR_ENCRYPTION) - 1 - XAR_ENCRYPTION.find(c)]
    return encrypted_password

def decrypt_password(encrypted_string):
    decrypted_password = ''
    for c in encrypted_string:
        decrypted_password = decrypted_password + XAR_ENCRYPTION[len(XAR_ENCRYPTION) - 1 - XAR_ENCRYPTION.find(c)]
    return decrypted_password

def fetch_userid_and_password():
    userid = ""
    password = ""
    userid_filepath = get_userid_filepath()
    if (os.path.exists(userid_filepath)):
        with open(userid_filepath, 'r') as userid_file:
            userid_password = userid_file.read()
            line_split = userid_password.split(':')
            userid = line_split[0]
            encrypted_password = line_split[1]
            password = decrypt_password(encrypted_password)
    else:
        print("Userid file doesn't exist.")
    return [userid, password]

def save_userid_and_password_locally(userid, password):
    try:
        roaming_dir = Path().home() / 'AppData' / 'Roaming'
        userid_directory_path = bpy.path.abspath(f"{roaming_dir}/{XAR_APP_DATA_DIRECTORY}")
        if not os.path.exists(userid_directory_path):
            os.makedirs(userid_directory_path)
        userid_filepath = bpy.path.abspath(f"{userid_directory_path}/{XAR_USERID_FILENAME}")
        with open(userid_filepath, 'w') as userid_file:
            encrypted_password = encrypt_password(password)
            userid_file.write(userid + ':' + encrypted_password)
    except Exception as exc:
        print("Failed to overwrite userid file " + str(exc))

def save_userid_and_password(userid, password):
    user_id_change = userid != xarkin_network_service.global_userid
    previous_invalid_password = len(xarkin_network_service.global_password) < xarkin_network_service.XAR_MIN_PASSWORD_LENGTH
    save_userid_and_password_locally(userid, password)
    if (user_id_change or previous_invalid_password):
        thread = threading.Thread(target=fetch_user_data)
        thread.start()

def fetch_config_parameter(parameter_name):
    parameter_value = None
    try:
        addon_name = os.path.basename(os.path.dirname(__file__))
        addon_dir = bpy.utils.script_path_user() + '/addons/' + addon_name
        config_filepath = bpy.path.abspath(f"{addon_dir}/{XAR_CONFIG_FILENAME}")
        with open(config_filepath, 'r') as config_file:
            for line in config_file:
                line_parts = line.strip().split('=')
                if (line_parts[0] == parameter_name):
                    parameter_value = line_parts[1]
    except Exception as exc:
        print("Exception trying to read config file\n" + str(exc))
        parameter_value = None
    return parameter_value

def fetch_user_data():
    [userid, password] = fetch_userid_and_password()
    xarkin_network_service.fetch_user_info(userid, password)
    processed = False
    while not processed:
        if hasattr(bpy.data, 'objects'):
            processed = True
        else:
            print("objects DOESN'T exist so sleep again")
            time.sleep(1)

def get_mappings_list():
    if (session_data.get(XAR_MAPPINGS_DATA) is None):
        try:
            session_data[XAR_MAPPINGS_DATA] = []
        except:
            return None
    return session_data[XAR_MAPPINGS_DATA]

def get_cycles_list():
    if (session_data == None):
        return None
    if (session_data.get(XAR_CYCLES_DATA) is None):
        try:
            session_data[XAR_CYCLES_DATA] = []
        except:
            return None
    return session_data[XAR_CYCLES_DATA]

def get_subject_armature_name():
    armature_names = []
    selected_armatures = []
    for x in bpy.data.objects:
        if (str(x.type) == 'ARMATURE'):
            armature_names.append(x.name)
            if (x.select_get()):
                selected_armatures.append(x.name)
    if (len(selected_armatures) == 1):
        return selected_armatures[0]
    if (len(armature_names) == 1):
        return armature_names[0]
    most_recent_armature = get_session_variable("most_recent_armature")
    if (most_recent_armature == None):
        if (len(selected_armatures) > 0):
            return selected_armatures[0]
        if (len(armature_names) > 0):
            return armature_names[0]
    else:
        for name in selected_armatures:
            if (name == most_recent_armature):
                return name
        for name in armature_names:
            if (name == most_recent_armature):
                return name
    return None

def set_server_result(message):
    global server_result
    global frame_node_count

    server_result = message
    try:
        sequence_dom = xml.dom.minidom.parseString(server_result)
        frame_nodes = sequence_dom.getElementsByTagName(xarkin_frame_importer.XAR_FRAME_TAG)
        frame_node_count = frame_nodes.length
    except Exception as exc:
        frame_node_count = -1

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Script copyright (C) Xarkin Software Inc.
# Contact Info: www.xarkinsoftware.com

import bpy
import importlib
import time
import threading
from bpy.props import (
        IntProperty,
        FloatProperty,
        StringProperty,
        BoolProperty,
        EnumProperty
        )
from . import xarkin_session_data
from . import xarkin_utilities
from . import xarkin_message_dialog
from . import xarkin_network_service
from . import xarkin_xml_exporter

global_parameters_xml = ''
global_interval_xml = ''

def get_armature_items(self, context):
    item_list = []
    if hasattr(bpy.data, 'objects'):
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                next_item = [x.name, x.name, x.name]
                item_list.append(tuple(next_item))
    return item_list

def make_service_call():
    global global_parameters_xml
    global global_interval_xml
    xarkin_network_service.interval_service_request(xarkin_network_service.XAR_TURN_OPERATION, global_parameters_xml, global_interval_xml)

class XarkinTurnDialog(bpy.types.Operator):
    bl_idname = "object.xarkin_turn_dialog"
    bl_label = "Turn"
    bl_description = "Requests a change of direction to occur over the specified frame range.  Left turns are positive, right turns are negative"

    network_service_busy = False

    wait_and_abort_options = [("wait", "Keep Waiting...", "Keep waiting for the current operation to complete."), ("abort", "Abort", "Abandon the current operation.")]
    wait_or_abort_prop: EnumProperty(name='Actions', items=wait_and_abort_options, default=wait_and_abort_options[0][0])

    armatures_prop: EnumProperty(items=get_armature_items, name="", default=None)
    mapping_source_prop: EnumProperty(items=xarkin_network_service.get_mapping_source_items, name="", default=None)
    mapping_name_prop: EnumProperty(items=xarkin_network_service.get_mapping_name_items, name="", default=None)
    first_frame_prop: IntProperty(name="", default=1, min=1)
    last_frame_prop: IntProperty(name="", default=1, min=1)
    last_affected_frame_prop: IntProperty(name="", default=1, min=1)
    turn_degrees_prop: IntProperty(name="", default=0, min=-90, max=90)
    
    def draw(self, context):
        layout = self.layout
        
        if self.network_service_busy:
            layout.label(text="An operation is already in progress!")
            for option in self.wait_and_abort_options:
                layout.prop_enum(self, 'wait_or_abort_prop', option[0], text=option[1])
        else:
            row1 = layout.row()
            split1 = row1.split(factor=0.285)
            split1.label(text="Armature")
            split1.prop(self, 'armatures_prop')

            row2 = layout.row()
            split2 = row2.split(factor=0.65)
            src2_split = split2.split(factor=0.46154)
            src2_split.label(text='Mapping')
            src2_split.prop(self, 'mapping_source_prop')
            split2.prop(self, 'mapping_name_prop')
            
            row3 = layout.row()
            split3 = row3.split(factor=0.285)
            split3.label(text="First Frame")
            split3.prop(self, 'first_frame_prop')
            
            row4 = layout.row()
            split4 = row4.split(factor=0.285)
            split4.label(text="Last Frame")
            split4.prop(self, 'last_frame_prop')
            
            row5 = layout.row()
            split5 = row5.split(factor=0.285)
            split5.label(text="Last Affected")
            split5.prop(self, 'last_affected_frame_prop')
            
            row6 = layout.row()
            split6 = row6.split(factor=0.285)
            split6.label(text="Turn Degrees")
            split6.prop(self, 'turn_degrees_prop')

    def invoke(self, context, event):
        self.network_service_busy = not xarkin_network_service.idle()

        armature_count = 0
        for x in bpy.data.objects:
            if (str(x.type) == 'ARMATURE'):
                armature_count = armature_count + 1
        if (armature_count == 0):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No Armatures Available')
            return  {'FINISHED'}

        subject_arm_name = xarkin_session_data.get_subject_armature_name()
        self.armatures_prop = subject_arm_name
        if (subject_arm_name != None):
            armature_obj = bpy.data.objects[self.armatures_prop]
            anim_data = armature_obj.animation_data
            if (anim_data is not None) and (anim_data.action is not None):
                last_frame = 1
                for fcurve in anim_data.action.fcurves:
                    for key_frame in fcurve.keyframe_points:
                        if key_frame.co.x > last_frame:
                            last_frame = key_frame.co.x
                self.last_affected_frame_prop = int(last_frame)

        self.first_frame_prop = min(int(self.last_affected_frame_prop), bpy.context.scene.frame_current)
        self.last_frame_prop = int(self.first_frame_prop)

        most_recent_mapping_name = xarkin_session_data.get_session_variable("most_recent_mapping_name")
        if (not most_recent_mapping_name == None):
            m_items = xarkin_network_service.get_mapping_items(self, None)
            for item in m_items:
                if (item[1] == most_recent_mapping_name) or (('Standard:' + item[1]) == most_recent_mapping_name):
                    colon_pos = most_recent_mapping_name.find(':')
                    map_src = most_recent_mapping_name[0:colon_pos]
                    map_nam = most_recent_mapping_name[colon_pos + 1:]
                    self.mapping_source_prop = map_src
                    self.mapping_name_prop = map_nam

        most_recent_turn_degrees = xarkin_session_data.get_session_variable("most_recent_turn_degrees")
        if (not most_recent_turn_degrees == None):
                self.turn_degrees_prop = most_recent_turn_degrees
                
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if self.network_service_busy:
            if (self.wait_or_abort_prop == 'abort'):
                xarkin_network_service.abort()
            return {'FINISHED'}
        xarkin_session_data.set_session_variable("most_recent_armature", self.armatures_prop)
        xarkin_session_data.set_session_variable("most_recent_mapping_name", self.mapping_source_prop + ':' + self.mapping_name_prop)
        xarkin_session_data.set_session_variable("most_recent_turn_degrees", self.turn_degrees_prop)
        if (self.mapping_source_prop == xarkin_utilities.XAR_NONE):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='No mappings for this character.\nPlease create one before attempting operations.')
            return {'FINISHED'}
        first_frame = self.first_frame_prop
        last_frame = self.last_frame_prop
        last_affected_frame = self.last_affected_frame_prop
        if (last_frame == first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='First Frame and Last Frame should surround the\n'\
                'interval containing the step you would like to modify.\n'\
                    'The first candidate step in that interval will be modified.')
            return {'FINISHED'}
        elif (last_frame < first_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Last Frame must be greater than First Frame.')
            return {'FINISHED'}
        elif ((last_frame - first_frame) < 10):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='This looks like too few frames to contain a step.\n'\
                'This warning is issued if the interval is less than 10 frames.')
            return {'FINISHED'}
        elif (last_affected_frame < last_frame):
            bpy.ops.object.xarkin_message('INVOKE_DEFAULT', msg='Last affected frame must at least be the last frame of the turn.')
            return {'FINISHED'}

        bpy.ops.ed.undo_push(message="Before requesting turn.")

        exporter = xarkin_xml_exporter.EditorXMLExporter()

        first_export_frame = first_frame
        lead_buffer = 0
        for i in range(2):
            if (first_export_frame > 0):
                first_export_frame = first_export_frame - 1
                lead_buffer = lead_buffer + 1
        additional_frames = last_affected_frame - last_frame
        trail_buffer = additional_frames

        interval_xml = exporter.get_mogen(self.armatures_prop, first_export_frame, last_affected_frame)

        whole_mapping_name = self.mapping_name_prop
        if (self.mapping_source_prop != xarkin_utilities.XAR_STANDARD_NAME):
            whole_mapping_name = self.mapping_source_prop + ':' + self.mapping_name_prop

        mapping_list = xarkin_session_data.get_mappings_list()
        topology = "unknown"
        for mapping_index in range(len(mapping_list)):
            if (mapping_list[mapping_index][1] == whole_mapping_name):
                topology = mapping_list[mapping_index][0]

        parameters_xml = '<parameters>'
        parameters_xml += '<parameter name="operation" value="turn_degrees" />'
        parameters_xml += '<parameter name="armature_name" value="' + self.armatures_prop + '" />'
        parameters_xml += '<parameter name="mapping_name" value="' + whole_mapping_name + '" />'
        parameters_xml += '<parameter name="topology" value="' + topology + '" />'
        parameters_xml += '<parameter name="first_frame" value="' + str(first_frame) + '" />'
        parameters_xml += '<parameter name="last_frame" value="' + str(last_frame) + '" />'
        parameters_xml += '<parameter name="lead_buffer" value="' + str(lead_buffer) + '" />'
        parameters_xml += '<parameter name="trail_buffer" value="' + str(trail_buffer) + '" />'
        parameters_xml += '<parameter name="delta_heading" value="' + str(self.turn_degrees_prop)  + '" />'
        parameters_xml += '</parameters>'

        global global_parameters_xml
        global global_interval_xml
        global_parameters_xml = parameters_xml
        global_interval_xml = interval_xml
        xarkin_network_service.global_first_import_frame = first_frame
        thread = threading.Thread(target=make_service_call)
        thread.start()
        return {'FINISHED'}
